data:extend(
{
	{
		type = "item-subgroup",
		name = "electric-transport-log",
		group = "logistics",
		order = "ee",
	},
	{
		type = "item-subgroup",
		name = "electric-transport-cargo",
		group = "logistics",
		order = "ef",
	},
	{
		type = "item-subgroup",
		name = "electric-transport-fluid",
		group = "logistics",
		order = "eg",
	}
})