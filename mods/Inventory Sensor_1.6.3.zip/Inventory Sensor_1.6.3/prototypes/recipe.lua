data:extend({
  {
    type = "recipe",
    name = "item-sensor",
    icon = "__Inventory Sensor__/graphics/icons/inventory-sensor.png",
    icon_size = 32,
    enabled = "false",
    ingredients =
    {
      {"constant-combinator", 1},
      {"advanced-circuit", 5}
    },
    result = "item-sensor"
  }
})
