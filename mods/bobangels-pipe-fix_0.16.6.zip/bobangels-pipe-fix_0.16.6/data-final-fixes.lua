for _,dat in pairs(data.raw) do
	for _,item in pairs(dat) do
		if 
			item.name == "copper-pipe" or
			item.name == "brass-pipe" or
			item.name == "bronze-pipe"or
			item.name == "copper-pipe-to-ground" or
			item.name == "brass-pipe-to-ground" or
			item.name == "bronze-pipe-to-ground"
		then
			for k, v in pairs(item) do
				if k == "fluid_box" then
					v.base_area = 1
				end
			end
		end
	end
end

