data:extend{
    {
        type = "bool-setting",
        name = "start-with-unit-remote-control",
        setting_type = "startup",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "path-visualisation",
        setting_type = "runtime-global",
        default_value = true,
    }
}
