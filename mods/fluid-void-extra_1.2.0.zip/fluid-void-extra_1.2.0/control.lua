-------------------------------------------------------------------------------
--FACTORIO MOD: Fluid Void Extra
--A mod, redesigned from Rseding91's Fluid Void Mod, to work properly for newer versions.
--Author: Nibuja05
--Date: 08.02.2018
-------------------------------------------------------------------------------


script.on_event(defines.events.on_built_entity,
	function (event)
   		savePipe(event.created_entity)	
   	end
)

script.on_event(defines.events.on_robot_built_entity,
   	function (event)
   		savePipe(event.created_entity)	
   	end
)

script.on_event({defines.events.on_tick},
   function (e)
      	processPipes()
   end
)

function savePipe(entity)
	if entity.name == "void-pipe" then
		if global.pipes == nil then
			global.pipes = {}
		end
		table.insert(global.pipes, entity)
	end
end

function processPipes()
	if global.pipes ~= nil then
		for k,pipe in pairs(global.pipes) do
			if pipe.valid then
				pipe.fluidbox[1] = nil
			else
				table.remove(global.pipes, k)
				if #global.pipes == 0 then
					global.pipes = nil
				end
			end
		end
	end
end