
data:extend({
	{
	    type = "item",
	    name = "void-pipe",
	    icon = "__fluid-void-extra__/graphics/void-pipe.png",
	    icon_size = 32,
	    flags = {"goes-to-quickbar"},
	    subgroup = "storage",
	    order = "a[items]-d[void-pipe]",
	    place_result = "void-pipe",
	    stack_size = 50
	},
})