

data:extend({
	{
		type = "recipe",
	    name = "void-pipe",
		energy_required = 4,
		enabled = true,
		ingredients = {{"pipe", 5}},
		result = "void-pipe",
		result_count = 1
	},
})