require("functions")

if recipe("loader") then
require("prototypes.recipe2")
end

if recipe("electric-stone-furnace") then
require("prototypes.recipe1")
end