require("functions")

recipe("loader").ingredients = {{"inserter", 5},{"basic-circuit-board", 10},{"iron-gear-wheel", 5},{"transport-belt", 5}}