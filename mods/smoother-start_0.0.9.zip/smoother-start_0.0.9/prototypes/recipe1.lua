require("functions")

recipe("electric-stone-furnace").ingredients = {{"stone-furnace", 1},{"basic-circuit-board", 2},{	"iron-plate", 1}}