table.insert(
    data.raw["technology"]["construction-robotics"]["effects"],
    { type = "unlock-recipe", recipe = "module-inserter" }
)
