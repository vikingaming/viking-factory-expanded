return {
  {
    entity_number = 1,
    name = "transport-belt",
    position = {
      x = 0,
      y = -1
    }
  },
  {
    entity_number = 2,
    name = "transport-belt",
    position = {
      x = -1,
      y = -1
    }
  },
  {
    entity_number = 3,
    name = "splitter",
    position = {
      x = -0.5,
      y = 0
    }
  },
  {
    entity_number = 4,
    name = "transport-belt",
    position = {
      x = 0,
      y = 1
    }
  },
  {
    entity_number = 5,
    name = "transport-belt",
    position = {
      x = -1,
      y = 1
    }
  }
}