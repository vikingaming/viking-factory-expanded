return {
  {
    direction = 4,
    entity_number = 1,
    name = "splitter",
    position = {
      x = -15.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 2,
    name = "splitter",
    position = {
      x = -13.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 3,
    name = "splitter",
    position = {
      x = -11.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 4,
    name = "splitter",
    position = {
      x = -9.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 5,
    name = "splitter",
    position = {
      x = -7.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 6,
    name = "splitter",
    position = {
      x = -5.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 7,
    name = "splitter",
    position = {
      x = -3.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 8,
    name = "splitter",
    position = {
      x = -1.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 9,
    name = "splitter",
    position = {
      x = 0.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 10,
    name = "splitter",
    position = {
      x = 2.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 11,
    name = "splitter",
    position = {
      x = 4.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 12,
    name = "splitter",
    position = {
      x = 6.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 13,
    name = "splitter",
    position = {
      x = 8.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 14,
    name = "splitter",
    position = {
      x = 10.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 15,
    name = "splitter",
    position = {
      x = 12.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 16,
    name = "splitter",
    position = {
      x = 14.5,
      y = -23
    }
  },
  {
    direction = 4,
    entity_number = 17,
    name = "transport-belt",
    position = {
      x = -16,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 18,
    name = "transport-belt",
    position = {
      x = -16,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 19,
    name = "underground-belt",
    position = {
      x = -15,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 20,
    name = "splitter",
    position = {
      x = -14.5,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 21,
    name = "underground-belt",
    position = {
      x = -14,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 22,
    name = "transport-belt",
    position = {
      x = -13,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 23,
    name = "transport-belt",
    position = {
      x = -13,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 24,
    name = "transport-belt",
    position = {
      x = -12,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 25,
    name = "transport-belt",
    position = {
      x = -12,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 26,
    name = "splitter",
    position = {
      x = -10.5,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 27,
    name = "underground-belt",
    position = {
      x = -11,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 28,
    name = "underground-belt",
    position = {
      x = -10,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 29,
    name = "transport-belt",
    position = {
      x = -9,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 30,
    name = "transport-belt",
    position = {
      x = -9,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 31,
    name = "transport-belt",
    position = {
      x = -8,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 32,
    name = "transport-belt",
    position = {
      x = -8,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 33,
    name = "splitter",
    position = {
      x = -6.5,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 34,
    name = "underground-belt",
    position = {
      x = -7,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 35,
    name = "underground-belt",
    position = {
      x = -6,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 36,
    name = "transport-belt",
    position = {
      x = -4,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 37,
    name = "transport-belt",
    position = {
      x = -5,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 38,
    name = "transport-belt",
    position = {
      x = -5,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 39,
    name = "transport-belt",
    position = {
      x = -4,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 40,
    name = "underground-belt",
    position = {
      x = -2,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 41,
    name = "splitter",
    position = {
      x = -2.5,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 42,
    name = "underground-belt",
    position = {
      x = -3,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 43,
    name = "transport-belt",
    position = {
      x = -1,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 44,
    name = "transport-belt",
    position = {
      x = -1,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 45,
    name = "transport-belt",
    position = {
      x = 0,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 46,
    name = "transport-belt",
    position = {
      x = 0,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 47,
    name = "underground-belt",
    position = {
      x = 2,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 48,
    name = "underground-belt",
    position = {
      x = 1,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 49,
    name = "splitter",
    position = {
      x = 1.5,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 50,
    name = "transport-belt",
    position = {
      x = 3,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 51,
    name = "transport-belt",
    position = {
      x = 3,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 52,
    name = "transport-belt",
    position = {
      x = 4,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 53,
    name = "transport-belt",
    position = {
      x = 4,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 54,
    name = "underground-belt",
    position = {
      x = 5,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 55,
    name = "underground-belt",
    position = {
      x = 6,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 56,
    name = "splitter",
    position = {
      x = 5.5,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 57,
    name = "transport-belt",
    position = {
      x = 7,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 58,
    name = "transport-belt",
    position = {
      x = 8,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 59,
    name = "transport-belt",
    position = {
      x = 7,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 60,
    name = "transport-belt",
    position = {
      x = 8,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 61,
    name = "underground-belt",
    position = {
      x = 9,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 62,
    name = "underground-belt",
    position = {
      x = 10,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 63,
    name = "splitter",
    position = {
      x = 9.5,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 64,
    name = "transport-belt",
    position = {
      x = 11,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 65,
    name = "transport-belt",
    position = {
      x = 11,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 66,
    name = "transport-belt",
    position = {
      x = 12,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 67,
    name = "transport-belt",
    position = {
      x = 12,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 68,
    name = "underground-belt",
    position = {
      x = 14,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 69,
    name = "underground-belt",
    position = {
      x = 13,
      y = -21
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 70,
    name = "splitter",
    position = {
      x = 13.5,
      y = -22
    }
  },
  {
    direction = 4,
    entity_number = 71,
    name = "transport-belt",
    position = {
      x = 15,
      y = -21
    }
  },
  {
    direction = 4,
    entity_number = 72,
    name = "transport-belt",
    position = {
      x = 15,
      y = -22
    }
  },
  {
    direction = 2,
    entity_number = 73,
    name = "transport-belt",
    position = {
      x = -16,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 74,
    name = "transport-belt",
    position = {
      x = -15,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 75,
    name = "transport-belt",
    position = {
      x = -14,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 76,
    name = "splitter",
    position = {
      x = -14.5,
      y = -19
    }
  },
  {
    direction = 6,
    entity_number = 77,
    name = "transport-belt",
    position = {
      x = -13,
      y = -20
    }
  },
  {
    direction = 2,
    entity_number = 78,
    name = "transport-belt",
    position = {
      x = -12,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 79,
    name = "transport-belt",
    position = {
      x = -11,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 80,
    name = "splitter",
    position = {
      x = -10.5,
      y = -19
    }
  },
  {
    direction = 4,
    entity_number = 81,
    name = "transport-belt",
    position = {
      x = -10,
      y = -20
    }
  },
  {
    direction = 6,
    entity_number = 82,
    name = "transport-belt",
    position = {
      x = -9,
      y = -20
    }
  },
  {
    direction = 2,
    entity_number = 83,
    name = "transport-belt",
    position = {
      x = -8,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 84,
    name = "transport-belt",
    position = {
      x = -7,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 85,
    name = "transport-belt",
    position = {
      x = -6,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 86,
    name = "splitter",
    position = {
      x = -6.5,
      y = -19
    }
  },
  {
    direction = 6,
    entity_number = 87,
    name = "transport-belt",
    position = {
      x = -5,
      y = -20
    }
  },
  {
    direction = 2,
    entity_number = 88,
    name = "transport-belt",
    position = {
      x = -4,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 89,
    name = "transport-belt",
    position = {
      x = -3,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 90,
    name = "splitter",
    position = {
      x = -2.5,
      y = -19
    }
  },
  {
    direction = 4,
    entity_number = 91,
    name = "transport-belt",
    position = {
      x = -2,
      y = -20
    }
  },
  {
    direction = 6,
    entity_number = 92,
    name = "transport-belt",
    position = {
      x = -1,
      y = -20
    }
  },
  {
    direction = 2,
    entity_number = 93,
    name = "transport-belt",
    position = {
      x = 0,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 94,
    name = "transport-belt",
    position = {
      x = 1,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 95,
    name = "transport-belt",
    position = {
      x = 2,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 96,
    name = "splitter",
    position = {
      x = 1.5,
      y = -19
    }
  },
  {
    direction = 6,
    entity_number = 97,
    name = "transport-belt",
    position = {
      x = 3,
      y = -20
    }
  },
  {
    direction = 2,
    entity_number = 98,
    name = "transport-belt",
    position = {
      x = 4,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 99,
    name = "transport-belt",
    position = {
      x = 6,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 100,
    name = "transport-belt",
    position = {
      x = 5,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 101,
    name = "splitter",
    position = {
      x = 5.5,
      y = -19
    }
  },
  {
    direction = 2,
    entity_number = 102,
    name = "transport-belt",
    position = {
      x = 8,
      y = -20
    }
  },
  {
    direction = 6,
    entity_number = 103,
    name = "transport-belt",
    position = {
      x = 7,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 104,
    name = "transport-belt",
    position = {
      x = 9,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 105,
    name = "transport-belt",
    position = {
      x = 10,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 106,
    name = "splitter",
    position = {
      x = 9.5,
      y = -19
    }
  },
  {
    direction = 6,
    entity_number = 107,
    name = "transport-belt",
    position = {
      x = 11,
      y = -20
    }
  },
  {
    direction = 2,
    entity_number = 108,
    name = "transport-belt",
    position = {
      x = 12,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 109,
    name = "transport-belt",
    position = {
      x = 13,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 110,
    name = "transport-belt",
    position = {
      x = 14,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 111,
    name = "splitter",
    position = {
      x = 13.5,
      y = -19
    }
  },
  {
    direction = 6,
    entity_number = 112,
    name = "transport-belt",
    position = {
      x = 15,
      y = -20
    }
  },
  {
    direction = 4,
    entity_number = 113,
    name = "transport-belt",
    position = {
      x = -16,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 114,
    name = "transport-belt",
    position = {
      x = -16,
      y = -18
    }
  },
  {
    direction = 6,
    entity_number = 115,
    name = "transport-belt",
    position = {
      x = -15,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 116,
    name = "underground-belt",
    position = {
      x = -15,
      y = -17
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 117,
    name = "transport-belt",
    position = {
      x = -14,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 118,
    name = "underground-belt",
    position = {
      x = -14,
      y = -17
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 119,
    name = "transport-belt",
    position = {
      x = -13,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 120,
    name = "transport-belt",
    position = {
      x = -13,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 121,
    name = "transport-belt",
    position = {
      x = -12,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 122,
    name = "transport-belt",
    position = {
      x = -12,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 123,
    name = "underground-belt",
    position = {
      x = -11,
      y = -17
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 124,
    name = "transport-belt",
    position = {
      x = -11,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 125,
    name = "underground-belt",
    position = {
      x = -10,
      y = -17
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 126,
    name = "transport-belt",
    position = {
      x = -10,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 127,
    name = "transport-belt",
    position = {
      x = -9,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 128,
    name = "transport-belt",
    position = {
      x = -9,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 129,
    name = "transport-belt",
    position = {
      x = -8,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 130,
    name = "transport-belt",
    position = {
      x = -8,
      y = -17
    }
  },
  {
    direction = 6,
    entity_number = 131,
    name = "transport-belt",
    position = {
      x = -7,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 132,
    name = "underground-belt",
    position = {
      x = -7,
      y = -17
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 133,
    name = "transport-belt",
    position = {
      x = -6,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 134,
    name = "underground-belt",
    position = {
      x = -6,
      y = -17
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 135,
    name = "transport-belt",
    position = {
      x = -5,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 136,
    name = "transport-belt",
    position = {
      x = -5,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 137,
    name = "transport-belt",
    position = {
      x = -4,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 138,
    name = "transport-belt",
    position = {
      x = -4,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 139,
    name = "underground-belt",
    position = {
      x = -3,
      y = -17
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 140,
    name = "transport-belt",
    position = {
      x = -3,
      y = -18
    }
  },
  {
    direction = 2,
    entity_number = 141,
    name = "transport-belt",
    position = {
      x = -2,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 142,
    name = "underground-belt",
    position = {
      x = -2,
      y = -17
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 143,
    name = "transport-belt",
    position = {
      x = -1,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 144,
    name = "transport-belt",
    position = {
      x = -1,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 145,
    name = "transport-belt",
    position = {
      x = 0,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 146,
    name = "transport-belt",
    position = {
      x = 0,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 147,
    name = "underground-belt",
    position = {
      x = 2,
      y = -17
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 148,
    name = "underground-belt",
    position = {
      x = 1,
      y = -17
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 149,
    name = "transport-belt",
    position = {
      x = 1,
      y = -18
    }
  },
  {
    direction = 2,
    entity_number = 150,
    name = "transport-belt",
    position = {
      x = 2,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 151,
    name = "transport-belt",
    position = {
      x = 3,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 152,
    name = "transport-belt",
    position = {
      x = 4,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 153,
    name = "transport-belt",
    position = {
      x = 3,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 154,
    name = "transport-belt",
    position = {
      x = 4,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 155,
    name = "underground-belt",
    position = {
      x = 5,
      y = -17
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 156,
    name = "underground-belt",
    position = {
      x = 6,
      y = -17
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 157,
    name = "transport-belt",
    position = {
      x = 5,
      y = -18
    }
  },
  {
    direction = 2,
    entity_number = 158,
    name = "transport-belt",
    position = {
      x = 6,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 159,
    name = "transport-belt",
    position = {
      x = 7,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 160,
    name = "transport-belt",
    position = {
      x = 8,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 161,
    name = "transport-belt",
    position = {
      x = 7,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 162,
    name = "transport-belt",
    position = {
      x = 8,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 163,
    name = "underground-belt",
    position = {
      x = 9,
      y = -17
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 164,
    name = "underground-belt",
    position = {
      x = 10,
      y = -17
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 165,
    name = "transport-belt",
    position = {
      x = 9,
      y = -18
    }
  },
  {
    direction = 2,
    entity_number = 166,
    name = "transport-belt",
    position = {
      x = 10,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 167,
    name = "transport-belt",
    position = {
      x = 11,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 168,
    name = "transport-belt",
    position = {
      x = 12,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 169,
    name = "transport-belt",
    position = {
      x = 11,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 170,
    name = "transport-belt",
    position = {
      x = 12,
      y = -18
    }
  },
  {
    direction = 6,
    entity_number = 171,
    name = "transport-belt",
    position = {
      x = 13,
      y = -18
    }
  },
  {
    direction = 2,
    entity_number = 172,
    name = "transport-belt",
    position = {
      x = 14,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 173,
    name = "underground-belt",
    position = {
      x = 13,
      y = -17
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 174,
    name = "underground-belt",
    position = {
      x = 14,
      y = -17
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 175,
    name = "transport-belt",
    position = {
      x = 15,
      y = -17
    }
  },
  {
    direction = 4,
    entity_number = 176,
    name = "transport-belt",
    position = {
      x = 15,
      y = -18
    }
  },
  {
    direction = 4,
    entity_number = 177,
    name = "transport-belt",
    position = {
      x = -16,
      y = -16
    }
  },
  {
    direction = 2,
    entity_number = 178,
    name = "transport-belt",
    position = {
      x = -16,
      y = -15
    }
  },
  {
    direction = 4,
    entity_number = 179,
    name = "underground-belt",
    position = {
      x = -15,
      y = -16
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 180,
    name = "transport-belt",
    position = {
      x = -15,
      y = -15
    }
  },
  {
    direction = 4,
    entity_number = 181,
    name = "underground-belt",
    position = {
      x = -14,
      y = -16
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 182,
    name = "underground-belt",
    position = {
      x = -14,
      y = -15
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 183,
    name = "underground-belt",
    position = {
      x = -13,
      y = -15
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 184,
    name = "splitter",
    position = {
      x = -12.5,
      y = -16
    }
  },
  {
    direction = 4,
    entity_number = 185,
    name = "underground-belt",
    position = {
      x = -12,
      y = -15
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 186,
    name = "transport-belt",
    position = {
      x = -11,
      y = -16
    }
  },
  {
    direction = 4,
    entity_number = 187,
    name = "transport-belt",
    position = {
      x = -11,
      y = -15
    }
  },
  {
    direction = 2,
    entity_number = 188,
    name = "underground-belt",
    position = {
      x = -10,
      y = -15
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 189,
    name = "underground-belt",
    position = {
      x = -10,
      y = -16
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 190,
    name = "underground-belt",
    position = {
      x = -9,
      y = -16
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 191,
    name = "transport-belt",
    position = {
      x = -8,
      y = -16
    }
  },
  {
    direction = 4,
    entity_number = 192,
    name = "transport-belt",
    position = {
      x = -9,
      y = -15
    }
  },
  {
    direction = 2,
    entity_number = 193,
    name = "transport-belt",
    position = {
      x = -8,
      y = -15
    }
  },
  {
    direction = 4,
    entity_number = 194,
    name = "underground-belt",
    position = {
      x = -7,
      y = -16
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 195,
    name = "transport-belt",
    position = {
      x = -7,
      y = -15
    }
  },
  {
    direction = 4,
    entity_number = 196,
    name = "underground-belt",
    position = {
      x = -6,
      y = -16
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 197,
    name = "underground-belt",
    position = {
      x = -6,
      y = -15
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 198,
    name = "splitter",
    position = {
      x = -4.5,
      y = -16
    }
  },
  {
    direction = 4,
    entity_number = 199,
    name = "underground-belt",
    position = {
      x = -5,
      y = -15
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 200,
    name = "underground-belt",
    position = {
      x = -4,
      y = -15
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 201,
    name = "underground-belt",
    position = {
      x = -2,
      y = -15
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 202,
    name = "transport-belt",
    position = {
      x = -3,
      y = -16
    }
  },
  {
    direction = 4,
    entity_number = 203,
    name = "underground-belt",
    position = {
      x = -2,
      y = -16
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 204,
    name = "transport-belt",
    position = {
      x = -3,
      y = -15
    }
  },
  {
    direction = 4,
    entity_number = 205,
    name = "underground-belt",
    position = {
      x = -1,
      y = -16
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 206,
    name = "transport-belt",
    position = {
      x = -1,
      y = -15
    }
  },
  {
    direction = 4,
    entity_number = 207,
    name = "transport-belt",
    position = {
      x = 0,
      y = -16
    }
  },
  {
    direction = 2,
    entity_number = 208,
    name = "transport-belt",
    position = {
      x = 0,
      y = -15
    }
  },
  {
    direction = 4,
    entity_number = 209,
    name = "underground-belt",
    position = {
      x = 1,
      y = -16
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 210,
    name = "underground-belt",
    position = {
      x = 2,
      y = -16
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 211,
    name = "underground-belt",
    position = {
      x = 2,
      y = -15
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 212,
    name = "transport-belt",
    position = {
      x = 1,
      y = -15
    }
  },
  {
    direction = 4,
    entity_number = 213,
    name = "underground-belt",
    position = {
      x = 3,
      y = -15
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 214,
    name = "underground-belt",
    position = {
      x = 4,
      y = -15
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 215,
    name = "splitter",
    position = {
      x = 3.5,
      y = -16
    }
  },
  {
    direction = 4,
    entity_number = 216,
    name = "underground-belt",
    position = {
      x = 6,
      y = -16
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 217,
    name = "underground-belt",
    position = {
      x = 6,
      y = -15
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 218,
    name = "transport-belt",
    position = {
      x = 5,
      y = -16
    }
  },
  {
    direction = 4,
    entity_number = 219,
    name = "transport-belt",
    position = {
      x = 5,
      y = -15
    }
  },
  {
    direction = 4,
    entity_number = 220,
    name = "underground-belt",
    position = {
      x = 7,
      y = -16
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 221,
    name = "transport-belt",
    position = {
      x = 8,
      y = -16
    }
  },
  {
    direction = 4,
    entity_number = 222,
    name = "transport-belt",
    position = {
      x = 7,
      y = -15
    }
  },
  {
    direction = 2,
    entity_number = 223,
    name = "transport-belt",
    position = {
      x = 8,
      y = -15
    }
  },
  {
    direction = 4,
    entity_number = 224,
    name = "underground-belt",
    position = {
      x = 9,
      y = -16
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 225,
    name = "underground-belt",
    position = {
      x = 10,
      y = -16
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 226,
    name = "transport-belt",
    position = {
      x = 9,
      y = -15
    }
  },
  {
    direction = 2,
    entity_number = 227,
    name = "underground-belt",
    position = {
      x = 10,
      y = -15
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 228,
    name = "underground-belt",
    position = {
      x = 11,
      y = -15
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 229,
    name = "underground-belt",
    position = {
      x = 12,
      y = -15
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 230,
    name = "splitter",
    position = {
      x = 11.5,
      y = -16
    }
  },
  {
    direction = 4,
    entity_number = 231,
    name = "underground-belt",
    position = {
      x = 14,
      y = -16
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 232,
    name = "transport-belt",
    position = {
      x = 13,
      y = -16
    }
  },
  {
    direction = 4,
    entity_number = 233,
    name = "transport-belt",
    position = {
      x = 13,
      y = -15
    }
  },
  {
    direction = 2,
    entity_number = 234,
    name = "underground-belt",
    position = {
      x = 14,
      y = -15
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 235,
    name = "transport-belt",
    position = {
      x = 15,
      y = -15
    }
  },
  {
    direction = 4,
    entity_number = 236,
    name = "underground-belt",
    position = {
      x = 15,
      y = -16
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 237,
    name = "transport-belt",
    position = {
      x = -16,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 238,
    name = "transport-belt",
    position = {
      x = -16,
      y = -13
    }
  },
  {
    direction = 6,
    entity_number = 239,
    name = "transport-belt",
    position = {
      x = -15,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 240,
    name = "underground-belt",
    position = {
      x = -15,
      y = -13
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 241,
    name = "transport-belt",
    position = {
      x = -14,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 242,
    name = "underground-belt",
    position = {
      x = -14,
      y = -13
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 243,
    name = "transport-belt",
    position = {
      x = -13,
      y = -13
    }
  },
  {
    direction = 6,
    entity_number = 244,
    name = "transport-belt",
    position = {
      x = -13,
      y = -14
    }
  },
  {
    direction = 6,
    entity_number = 245,
    name = "transport-belt",
    position = {
      x = -12,
      y = -13
    }
  },
  {
    direction = 6,
    entity_number = 246,
    name = "transport-belt",
    position = {
      x = -12,
      y = -14
    }
  },
  {
    direction = 6,
    entity_number = 247,
    name = "transport-belt",
    position = {
      x = -11,
      y = -13
    }
  },
  {
    direction = 6,
    entity_number = 248,
    name = "transport-belt",
    position = {
      x = -11,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 249,
    name = "underground-belt",
    position = {
      x = -10,
      y = -14
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 250,
    name = "transport-belt",
    position = {
      x = -10,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 251,
    name = "transport-belt",
    position = {
      x = -9,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 252,
    name = "transport-belt",
    position = {
      x = -9,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 253,
    name = "transport-belt",
    position = {
      x = -8,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 254,
    name = "transport-belt",
    position = {
      x = -8,
      y = -13
    }
  },
  {
    direction = 6,
    entity_number = 255,
    name = "transport-belt",
    position = {
      x = -7,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 256,
    name = "underground-belt",
    position = {
      x = -7,
      y = -13
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 257,
    name = "transport-belt",
    position = {
      x = -6,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 258,
    name = "underground-belt",
    position = {
      x = -6,
      y = -13
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 259,
    name = "transport-belt",
    position = {
      x = -5,
      y = -13
    }
  },
  {
    direction = 6,
    entity_number = 260,
    name = "transport-belt",
    position = {
      x = -5,
      y = -14
    }
  },
  {
    direction = 6,
    entity_number = 261,
    name = "transport-belt",
    position = {
      x = -4,
      y = -14
    }
  },
  {
    direction = 6,
    entity_number = 262,
    name = "transport-belt",
    position = {
      x = -4,
      y = -13
    }
  },
  {
    direction = 6,
    entity_number = 263,
    name = "transport-belt",
    position = {
      x = -3,
      y = -13
    }
  },
  {
    direction = 6,
    entity_number = 264,
    name = "transport-belt",
    position = {
      x = -3,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 265,
    name = "underground-belt",
    position = {
      x = -2,
      y = -14
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 266,
    name = "transport-belt",
    position = {
      x = -2,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 267,
    name = "transport-belt",
    position = {
      x = -1,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 268,
    name = "transport-belt",
    position = {
      x = -1,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 269,
    name = "transport-belt",
    position = {
      x = 0,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 270,
    name = "transport-belt",
    position = {
      x = 0,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 271,
    name = "underground-belt",
    position = {
      x = 1,
      y = -13
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 272,
    name = "underground-belt",
    position = {
      x = 2,
      y = -13
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 273,
    name = "transport-belt",
    position = {
      x = 1,
      y = -14
    }
  },
  {
    direction = 6,
    entity_number = 274,
    name = "transport-belt",
    position = {
      x = 2,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 275,
    name = "transport-belt",
    position = {
      x = 3,
      y = -13
    }
  },
  {
    direction = 6,
    entity_number = 276,
    name = "transport-belt",
    position = {
      x = 3,
      y = -14
    }
  },
  {
    direction = 6,
    entity_number = 277,
    name = "transport-belt",
    position = {
      x = 4,
      y = -14
    }
  },
  {
    direction = 6,
    entity_number = 278,
    name = "transport-belt",
    position = {
      x = 4,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 279,
    name = "underground-belt",
    position = {
      x = 6,
      y = -14
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 280,
    name = "transport-belt",
    position = {
      x = 5,
      y = -14
    }
  },
  {
    direction = 6,
    entity_number = 281,
    name = "transport-belt",
    position = {
      x = 5,
      y = -13
    }
  },
  {
    direction = 6,
    entity_number = 282,
    name = "transport-belt",
    position = {
      x = 6,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 283,
    name = "transport-belt",
    position = {
      x = 7,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 284,
    name = "transport-belt",
    position = {
      x = 8,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 285,
    name = "transport-belt",
    position = {
      x = 8,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 286,
    name = "transport-belt",
    position = {
      x = 7,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 287,
    name = "underground-belt",
    position = {
      x = 10,
      y = -13
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 288,
    name = "underground-belt",
    position = {
      x = 9,
      y = -13
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 289,
    name = "transport-belt",
    position = {
      x = 9,
      y = -14
    }
  },
  {
    direction = 6,
    entity_number = 290,
    name = "transport-belt",
    position = {
      x = 10,
      y = -14
    }
  },
  {
    direction = 6,
    entity_number = 291,
    name = "transport-belt",
    position = {
      x = 11,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 292,
    name = "transport-belt",
    position = {
      x = 11,
      y = -13
    }
  },
  {
    direction = 6,
    entity_number = 293,
    name = "transport-belt",
    position = {
      x = 12,
      y = -14
    }
  },
  {
    direction = 6,
    entity_number = 294,
    name = "transport-belt",
    position = {
      x = 12,
      y = -13
    }
  },
  {
    direction = 6,
    entity_number = 295,
    name = "transport-belt",
    position = {
      x = 13,
      y = -13
    }
  },
  {
    direction = 6,
    entity_number = 296,
    name = "transport-belt",
    position = {
      x = 13,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 297,
    name = "underground-belt",
    position = {
      x = 14,
      y = -14
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 298,
    name = "transport-belt",
    position = {
      x = 14,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 299,
    name = "transport-belt",
    position = {
      x = 15,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 300,
    name = "transport-belt",
    position = {
      x = 15,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 301,
    name = "transport-belt",
    position = {
      x = -16,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 302,
    name = "transport-belt",
    position = {
      x = -16,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 303,
    name = "splitter",
    position = {
      x = -13.5,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 304,
    name = "transport-belt",
    position = {
      x = -15,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 305,
    name = "transport-belt",
    position = {
      x = -15,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 306,
    name = "transport-belt",
    position = {
      x = -14,
      y = -11
    }
  },
  {
    direction = 2,
    entity_number = 307,
    name = "transport-belt",
    position = {
      x = -13,
      y = -11
    }
  },
  {
    direction = 2,
    entity_number = 308,
    name = "transport-belt",
    position = {
      x = -12,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 309,
    name = "transport-belt",
    position = {
      x = -11,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 310,
    name = "transport-belt",
    position = {
      x = -10,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 311,
    name = "transport-belt",
    position = {
      x = -10,
      y = -12
    }
  },
  {
    direction = 6,
    entity_number = 312,
    name = "transport-belt",
    position = {
      x = -9,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 313,
    name = "underground-belt",
    position = {
      x = -9,
      y = -11
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 314,
    name = "transport-belt",
    position = {
      x = -8,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 315,
    name = "transport-belt",
    position = {
      x = -8,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 316,
    name = "splitter",
    position = {
      x = -5.5,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 317,
    name = "transport-belt",
    position = {
      x = -7,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 318,
    name = "transport-belt",
    position = {
      x = -7,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 319,
    name = "transport-belt",
    position = {
      x = -6,
      y = -11
    }
  },
  {
    direction = 2,
    entity_number = 320,
    name = "transport-belt",
    position = {
      x = -5,
      y = -11
    }
  },
  {
    direction = 2,
    entity_number = 321,
    name = "transport-belt",
    position = {
      x = -4,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 322,
    name = "transport-belt",
    position = {
      x = -3,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 323,
    name = "transport-belt",
    position = {
      x = -2,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 324,
    name = "transport-belt",
    position = {
      x = -2,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 325,
    name = "underground-belt",
    position = {
      x = -1,
      y = -11
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 326,
    name = "transport-belt",
    position = {
      x = -1,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 327,
    name = "transport-belt",
    position = {
      x = 0,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 328,
    name = "transport-belt",
    position = {
      x = 0,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 329,
    name = "splitter",
    position = {
      x = 2.5,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 330,
    name = "transport-belt",
    position = {
      x = 1,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 331,
    name = "transport-belt",
    position = {
      x = 1,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 332,
    name = "transport-belt",
    position = {
      x = 2,
      y = -11
    }
  },
  {
    direction = 2,
    entity_number = 333,
    name = "transport-belt",
    position = {
      x = 3,
      y = -11
    }
  },
  {
    direction = 2,
    entity_number = 334,
    name = "transport-belt",
    position = {
      x = 4,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 335,
    name = "transport-belt",
    position = {
      x = 6,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 336,
    name = "transport-belt",
    position = {
      x = 5,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 337,
    name = "transport-belt",
    position = {
      x = 6,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 338,
    name = "underground-belt",
    position = {
      x = 7,
      y = -11
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 339,
    name = "transport-belt",
    position = {
      x = 8,
      y = -12
    }
  },
  {
    direction = 6,
    entity_number = 340,
    name = "transport-belt",
    position = {
      x = 7,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 341,
    name = "transport-belt",
    position = {
      x = 8,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 342,
    name = "transport-belt",
    position = {
      x = 9,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 343,
    name = "transport-belt",
    position = {
      x = 10,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 344,
    name = "transport-belt",
    position = {
      x = 9,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 345,
    name = "splitter",
    position = {
      x = 10.5,
      y = -12
    }
  },
  {
    direction = 2,
    entity_number = 346,
    name = "transport-belt",
    position = {
      x = 12,
      y = -11
    }
  },
  {
    direction = 2,
    entity_number = 347,
    name = "transport-belt",
    position = {
      x = 11,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 348,
    name = "transport-belt",
    position = {
      x = 13,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 349,
    name = "transport-belt",
    position = {
      x = 14,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 350,
    name = "transport-belt",
    position = {
      x = 14,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 351,
    name = "underground-belt",
    position = {
      x = 15,
      y = -11
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 352,
    name = "transport-belt",
    position = {
      x = 15,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 353,
    name = "splitter",
    position = {
      x = -15.5,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 354,
    name = "transport-belt",
    position = {
      x = -16,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 355,
    name = "underground-belt",
    position = {
      x = -15,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 356,
    name = "transport-belt",
    position = {
      x = -14,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 357,
    name = "underground-belt",
    position = {
      x = -14,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 358,
    name = "transport-belt",
    position = {
      x = -13,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 359,
    name = "underground-belt",
    position = {
      x = -13,
      y = -10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 360,
    name = "underground-belt",
    position = {
      x = -12,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 361,
    name = "underground-belt",
    position = {
      x = -12,
      y = -10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 362,
    name = "splitter",
    position = {
      x = -9.5,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 363,
    name = "transport-belt",
    position = {
      x = -11,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 364,
    name = "underground-belt",
    position = {
      x = -11,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 365,
    name = "underground-belt",
    position = {
      x = -10,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 366,
    name = "splitter",
    position = {
      x = -7.5,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 367,
    name = "transport-belt",
    position = {
      x = -9,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 368,
    name = "underground-belt",
    position = {
      x = -8,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 369,
    name = "underground-belt",
    position = {
      x = -7,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 370,
    name = "transport-belt",
    position = {
      x = -6,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 371,
    name = "transport-belt",
    position = {
      x = -6,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 372,
    name = "underground-belt",
    position = {
      x = -4,
      y = -10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 373,
    name = "underground-belt",
    position = {
      x = -5,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 374,
    name = "underground-belt",
    position = {
      x = -5,
      y = -10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 375,
    name = "underground-belt",
    position = {
      x = -4,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 376,
    name = "transport-belt",
    position = {
      x = -2,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 377,
    name = "transport-belt",
    position = {
      x = -3,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 378,
    name = "underground-belt",
    position = {
      x = -3,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 379,
    name = "splitter",
    position = {
      x = -1.5,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 380,
    name = "splitter",
    position = {
      x = 0.5,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 381,
    name = "transport-belt",
    position = {
      x = -1,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 382,
    name = "transport-belt",
    position = {
      x = 0,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 383,
    name = "underground-belt",
    position = {
      x = 1,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 384,
    name = "underground-belt",
    position = {
      x = 2,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 385,
    name = "transport-belt",
    position = {
      x = 2,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 386,
    name = "underground-belt",
    position = {
      x = 4,
      y = -10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 387,
    name = "underground-belt",
    position = {
      x = 3,
      y = -10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 388,
    name = "underground-belt",
    position = {
      x = 4,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 389,
    name = "transport-belt",
    position = {
      x = 3,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 390,
    name = "underground-belt",
    position = {
      x = 5,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 391,
    name = "underground-belt",
    position = {
      x = 6,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 392,
    name = "transport-belt",
    position = {
      x = 5,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 393,
    name = "splitter",
    position = {
      x = 6.5,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 394,
    name = "underground-belt",
    position = {
      x = 8,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 395,
    name = "transport-belt",
    position = {
      x = 7,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 396,
    name = "splitter",
    position = {
      x = 8.5,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 397,
    name = "transport-belt",
    position = {
      x = 10,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 398,
    name = "underground-belt",
    position = {
      x = 9,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 399,
    name = "transport-belt",
    position = {
      x = 10,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 400,
    name = "underground-belt",
    position = {
      x = 12,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 401,
    name = "underground-belt",
    position = {
      x = 11,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 402,
    name = "underground-belt",
    position = {
      x = 11,
      y = -10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 403,
    name = "underground-belt",
    position = {
      x = 12,
      y = -10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 404,
    name = "transport-belt",
    position = {
      x = 13,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 405,
    name = "underground-belt",
    position = {
      x = 13,
      y = -9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 406,
    name = "transport-belt",
    position = {
      x = 14,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 407,
    name = "splitter",
    position = {
      x = 14.5,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 408,
    name = "transport-belt",
    position = {
      x = 15,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 409,
    name = "transport-belt",
    position = {
      x = -16,
      y = -7
    }
  },
  {
    direction = 4,
    entity_number = 410,
    name = "transport-belt",
    position = {
      x = -16,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 411,
    name = "transport-belt",
    position = {
      x = -15,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 412,
    name = "transport-belt",
    position = {
      x = -15,
      y = -7
    }
  },
  {
    direction = 6,
    entity_number = 413,
    name = "underground-belt",
    position = {
      x = -14,
      y = -8
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 414,
    name = "transport-belt",
    position = {
      x = -13,
      y = -7
    }
  },
  {
    direction = 4,
    entity_number = 415,
    name = "transport-belt",
    position = {
      x = -13,
      y = -8
    }
  },
  {
    direction = 2,
    entity_number = 416,
    name = "transport-belt",
    position = {
      x = -12,
      y = -7
    }
  },
  {
    direction = 6,
    entity_number = 417,
    name = "underground-belt",
    position = {
      x = -12,
      y = -8
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 418,
    name = "transport-belt",
    position = {
      x = -11,
      y = -7
    }
  },
  {
    direction = 6,
    entity_number = 419,
    name = "transport-belt",
    position = {
      x = -11,
      y = -8
    }
  },
  {
    direction = 2,
    entity_number = 420,
    name = "transport-belt",
    position = {
      x = -10,
      y = -7
    }
  },
  {
    direction = 6,
    entity_number = 421,
    name = "underground-belt",
    position = {
      x = -10,
      y = -8
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 422,
    name = "transport-belt",
    position = {
      x = -9,
      y = -7
    }
  },
  {
    direction = 2,
    entity_number = 423,
    name = "transport-belt",
    position = {
      x = -9,
      y = -8
    }
  },
  {
    direction = 2,
    entity_number = 424,
    name = "underground-belt",
    position = {
      x = -8,
      y = -7
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 425,
    name = "transport-belt",
    position = {
      x = -8,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 426,
    name = "transport-belt",
    position = {
      x = -7,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 427,
    name = "transport-belt",
    position = {
      x = -7,
      y = -7
    }
  },
  {
    direction = 4,
    entity_number = 428,
    name = "transport-belt",
    position = {
      x = -6,
      y = -8
    }
  },
  {
    direction = 2,
    entity_number = 429,
    name = "transport-belt",
    position = {
      x = -6,
      y = -7
    }
  },
  {
    direction = 2,
    entity_number = 430,
    name = "transport-belt",
    position = {
      x = -5,
      y = -7
    }
  },
  {
    direction = 4,
    entity_number = 431,
    name = "transport-belt",
    position = {
      x = -4,
      y = -7
    }
  },
  {
    direction = 6,
    entity_number = 432,
    name = "underground-belt",
    position = {
      x = -5,
      y = -8
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 433,
    name = "transport-belt",
    position = {
      x = -4,
      y = -8
    }
  },
  {
    direction = 6,
    entity_number = 434,
    name = "transport-belt",
    position = {
      x = -3,
      y = -8
    }
  },
  {
    direction = 6,
    entity_number = 435,
    name = "transport-belt",
    position = {
      x = -2,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 436,
    name = "transport-belt",
    position = {
      x = -2,
      y = -7
    }
  },
  {
    direction = 2,
    entity_number = 437,
    name = "underground-belt",
    position = {
      x = -3,
      y = -7
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 438,
    name = "transport-belt",
    position = {
      x = -1,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 439,
    name = "transport-belt",
    position = {
      x = -1,
      y = -7
    }
  },
  {
    direction = 4,
    entity_number = 440,
    name = "transport-belt",
    position = {
      x = 0,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 441,
    name = "transport-belt",
    position = {
      x = 0,
      y = -7
    }
  },
  {
    direction = 6,
    entity_number = 442,
    name = "underground-belt",
    position = {
      x = 2,
      y = -8
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 443,
    name = "transport-belt",
    position = {
      x = 1,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 444,
    name = "transport-belt",
    position = {
      x = 1,
      y = -7
    }
  },
  {
    direction = 6,
    entity_number = 445,
    name = "underground-belt",
    position = {
      x = 4,
      y = -8
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 446,
    name = "transport-belt",
    position = {
      x = 3,
      y = -8
    }
  },
  {
    direction = 2,
    entity_number = 447,
    name = "transport-belt",
    position = {
      x = 3,
      y = -7
    }
  },
  {
    direction = 2,
    entity_number = 448,
    name = "transport-belt",
    position = {
      x = 4,
      y = -7
    }
  },
  {
    direction = 6,
    entity_number = 449,
    name = "underground-belt",
    position = {
      x = 6,
      y = -8
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 450,
    name = "transport-belt",
    position = {
      x = 5,
      y = -7
    }
  },
  {
    direction = 2,
    entity_number = 451,
    name = "transport-belt",
    position = {
      x = 6,
      y = -7
    }
  },
  {
    direction = 6,
    entity_number = 452,
    name = "transport-belt",
    position = {
      x = 5,
      y = -8
    }
  },
  {
    direction = 2,
    entity_number = 453,
    name = "underground-belt",
    position = {
      x = 8,
      y = -7
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 454,
    name = "transport-belt",
    position = {
      x = 7,
      y = -8
    }
  },
  {
    direction = 2,
    entity_number = 455,
    name = "transport-belt",
    position = {
      x = 8,
      y = -8
    }
  },
  {
    direction = 2,
    entity_number = 456,
    name = "transport-belt",
    position = {
      x = 7,
      y = -7
    }
  },
  {
    direction = 2,
    entity_number = 457,
    name = "transport-belt",
    position = {
      x = 10,
      y = -7
    }
  },
  {
    direction = 4,
    entity_number = 458,
    name = "transport-belt",
    position = {
      x = 9,
      y = -7
    }
  },
  {
    direction = 4,
    entity_number = 459,
    name = "transport-belt",
    position = {
      x = 9,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 460,
    name = "transport-belt",
    position = {
      x = 10,
      y = -8
    }
  },
  {
    direction = 6,
    entity_number = 461,
    name = "underground-belt",
    position = {
      x = 11,
      y = -8
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 462,
    name = "transport-belt",
    position = {
      x = 11,
      y = -7
    }
  },
  {
    direction = 6,
    entity_number = 463,
    name = "transport-belt",
    position = {
      x = 12,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 464,
    name = "transport-belt",
    position = {
      x = 12,
      y = -7
    }
  },
  {
    direction = 6,
    entity_number = 465,
    name = "transport-belt",
    position = {
      x = 14,
      y = -8
    }
  },
  {
    direction = 2,
    entity_number = 466,
    name = "underground-belt",
    position = {
      x = 13,
      y = -7
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 467,
    name = "transport-belt",
    position = {
      x = 13,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 468,
    name = "transport-belt",
    position = {
      x = 14,
      y = -7
    }
  },
  {
    direction = 4,
    entity_number = 469,
    name = "transport-belt",
    position = {
      x = 15,
      y = -7
    }
  },
  {
    direction = 4,
    entity_number = 470,
    name = "transport-belt",
    position = {
      x = 15,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 471,
    name = "transport-belt",
    position = {
      x = -16,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 472,
    name = "transport-belt",
    position = {
      x = -16,
      y = -5
    }
  },
  {
    direction = 2,
    entity_number = 473,
    name = "transport-belt",
    position = {
      x = -15,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 474,
    name = "underground-belt",
    position = {
      x = -15,
      y = -5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 475,
    name = "transport-belt",
    position = {
      x = -14,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 476,
    name = "underground-belt",
    position = {
      x = -14,
      y = -5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 477,
    name = "transport-belt",
    position = {
      x = -13,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 478,
    name = "transport-belt",
    position = {
      x = -13,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 479,
    name = "underground-belt",
    position = {
      x = -12,
      y = -6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 480,
    name = "transport-belt",
    position = {
      x = -12,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 481,
    name = "underground-belt",
    position = {
      x = -11,
      y = -6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 482,
    name = "transport-belt",
    position = {
      x = -11,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 483,
    name = "underground-belt",
    position = {
      x = -10,
      y = -6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 484,
    name = "transport-belt",
    position = {
      x = -10,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 485,
    name = "transport-belt",
    position = {
      x = -9,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 486,
    name = "transport-belt",
    position = {
      x = -9,
      y = -5
    }
  },
  {
    direction = 6,
    entity_number = 487,
    name = "underground-belt",
    position = {
      x = -8,
      y = -6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 488,
    name = "underground-belt",
    position = {
      x = -8,
      y = -5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 489,
    name = "transport-belt",
    position = {
      x = -7,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 490,
    name = "underground-belt",
    position = {
      x = -7,
      y = -5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 491,
    name = "transport-belt",
    position = {
      x = -6,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 492,
    name = "transport-belt",
    position = {
      x = -6,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 493,
    name = "underground-belt",
    position = {
      x = -4,
      y = -5
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 494,
    name = "underground-belt",
    position = {
      x = -5,
      y = -6
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 495,
    name = "underground-belt",
    position = {
      x = -5,
      y = -5
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 496,
    name = "transport-belt",
    position = {
      x = -4,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 497,
    name = "transport-belt",
    position = {
      x = -3,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 498,
    name = "transport-belt",
    position = {
      x = -2,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 499,
    name = "underground-belt",
    position = {
      x = -3,
      y = -6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 500,
    name = "transport-belt",
    position = {
      x = -2,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 501,
    name = "transport-belt",
    position = {
      x = -1,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 502,
    name = "transport-belt",
    position = {
      x = -1,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 503,
    name = "transport-belt",
    position = {
      x = 0,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 504,
    name = "transport-belt",
    position = {
      x = 0,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 505,
    name = "underground-belt",
    position = {
      x = 1,
      y = -5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 506,
    name = "underground-belt",
    position = {
      x = 2,
      y = -5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 507,
    name = "transport-belt",
    position = {
      x = 1,
      y = -6
    }
  },
  {
    direction = 2,
    entity_number = 508,
    name = "transport-belt",
    position = {
      x = 2,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 509,
    name = "underground-belt",
    position = {
      x = 4,
      y = -6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 510,
    name = "transport-belt",
    position = {
      x = 3,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 511,
    name = "transport-belt",
    position = {
      x = 3,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 512,
    name = "transport-belt",
    position = {
      x = 4,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 513,
    name = "underground-belt",
    position = {
      x = 5,
      y = -6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 514,
    name = "underground-belt",
    position = {
      x = 6,
      y = -6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 515,
    name = "transport-belt",
    position = {
      x = 5,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 516,
    name = "transport-belt",
    position = {
      x = 6,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 517,
    name = "underground-belt",
    position = {
      x = 8,
      y = -5
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 518,
    name = "underground-belt",
    position = {
      x = 8,
      y = -6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 519,
    name = "transport-belt",
    position = {
      x = 7,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 520,
    name = "transport-belt",
    position = {
      x = 7,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 521,
    name = "underground-belt",
    position = {
      x = 9,
      y = -5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 522,
    name = "transport-belt",
    position = {
      x = 10,
      y = -5
    }
  },
  {
    direction = 2,
    entity_number = 523,
    name = "transport-belt",
    position = {
      x = 9,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 524,
    name = "transport-belt",
    position = {
      x = 10,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 525,
    name = "underground-belt",
    position = {
      x = 11,
      y = -5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 526,
    name = "underground-belt",
    position = {
      x = 12,
      y = -5
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 527,
    name = "underground-belt",
    position = {
      x = 11,
      y = -6
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 528,
    name = "transport-belt",
    position = {
      x = 12,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 529,
    name = "underground-belt",
    position = {
      x = 13,
      y = -6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 530,
    name = "transport-belt",
    position = {
      x = 13,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 531,
    name = "transport-belt",
    position = {
      x = 14,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 532,
    name = "transport-belt",
    position = {
      x = 14,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 533,
    name = "transport-belt",
    position = {
      x = 15,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 534,
    name = "transport-belt",
    position = {
      x = 15,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 535,
    name = "transport-belt",
    position = {
      x = -16,
      y = -4
    }
  },
  {
    direction = 4,
    entity_number = 536,
    name = "transport-belt",
    position = {
      x = -16,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 537,
    name = "transport-belt",
    position = {
      x = -15,
      y = -4
    }
  },
  {
    direction = 2,
    entity_number = 538,
    name = "transport-belt",
    position = {
      x = -15,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 539,
    name = "underground-belt",
    position = {
      x = -14,
      y = -4
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 540,
    name = "transport-belt",
    position = {
      x = -14,
      y = -3
    }
  },
  {
    direction = 2,
    entity_number = 541,
    name = "transport-belt",
    position = {
      x = -13,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 542,
    name = "underground-belt",
    position = {
      x = -13,
      y = -4
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 543,
    name = "underground-belt",
    position = {
      x = -12,
      y = -4
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 544,
    name = "underground-belt",
    position = {
      x = -12,
      y = -3
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 545,
    name = "transport-belt",
    position = {
      x = -11,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 546,
    name = "transport-belt",
    position = {
      x = -11,
      y = -4
    }
  },
  {
    direction = 4,
    entity_number = 547,
    name = "transport-belt",
    position = {
      x = -10,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 548,
    name = "underground-belt",
    position = {
      x = -10,
      y = -4
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 549,
    name = "underground-belt",
    position = {
      x = -9,
      y = -4
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 550,
    name = "transport-belt",
    position = {
      x = -9,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 551,
    name = "transport-belt",
    position = {
      x = -8,
      y = -4
    }
  },
  {
    direction = 6,
    entity_number = 552,
    name = "transport-belt",
    position = {
      x = -8,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 553,
    name = "underground-belt",
    position = {
      x = -7,
      y = -4
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 554,
    name = "underground-belt",
    position = {
      x = -7,
      y = -3
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 555,
    name = "underground-belt",
    position = {
      x = -6,
      y = -4
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 556,
    name = "transport-belt",
    position = {
      x = -6,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 557,
    name = "underground-belt",
    position = {
      x = -5,
      y = -4
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 558,
    name = "transport-belt",
    position = {
      x = -4,
      y = -4
    }
  },
  {
    direction = 2,
    entity_number = 559,
    name = "underground-belt",
    position = {
      x = -5,
      y = -3
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 560,
    name = "transport-belt",
    position = {
      x = -4,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 561,
    name = "underground-belt",
    position = {
      x = -2,
      y = -4
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 562,
    name = "underground-belt",
    position = {
      x = -3,
      y = -4
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 563,
    name = "underground-belt",
    position = {
      x = -3,
      y = -3
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 564,
    name = "transport-belt",
    position = {
      x = -2,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 565,
    name = "transport-belt",
    position = {
      x = -1,
      y = -4
    }
  },
  {
    direction = 4,
    entity_number = 566,
    name = "transport-belt",
    position = {
      x = -1,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 567,
    name = "transport-belt",
    position = {
      x = 0,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 568,
    name = "transport-belt",
    position = {
      x = 0,
      y = -4
    }
  },
  {
    direction = 4,
    entity_number = 569,
    name = "underground-belt",
    position = {
      x = 2,
      y = -4
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 570,
    name = "transport-belt",
    position = {
      x = 1,
      y = -4
    }
  },
  {
    direction = 2,
    entity_number = 571,
    name = "transport-belt",
    position = {
      x = 1,
      y = -3
    }
  },
  {
    direction = 2,
    entity_number = 572,
    name = "transport-belt",
    position = {
      x = 2,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 573,
    name = "underground-belt",
    position = {
      x = 4,
      y = -4
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 574,
    name = "underground-belt",
    position = {
      x = 3,
      y = -4
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 575,
    name = "underground-belt",
    position = {
      x = 4,
      y = -3
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 576,
    name = "transport-belt",
    position = {
      x = 3,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 577,
    name = "transport-belt",
    position = {
      x = 5,
      y = -4
    }
  },
  {
    direction = 4,
    entity_number = 578,
    name = "underground-belt",
    position = {
      x = 6,
      y = -4
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 579,
    name = "transport-belt",
    position = {
      x = 5,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 580,
    name = "transport-belt",
    position = {
      x = 6,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 581,
    name = "underground-belt",
    position = {
      x = 7,
      y = -4
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 582,
    name = "transport-belt",
    position = {
      x = 8,
      y = -4
    }
  },
  {
    direction = 6,
    entity_number = 583,
    name = "transport-belt",
    position = {
      x = 7,
      y = -3
    }
  },
  {
    direction = 6,
    entity_number = 584,
    name = "transport-belt",
    position = {
      x = 8,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 585,
    name = "underground-belt",
    position = {
      x = 9,
      y = -4
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 586,
    name = "underground-belt",
    position = {
      x = 9,
      y = -3
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 587,
    name = "transport-belt",
    position = {
      x = 10,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 588,
    name = "underground-belt",
    position = {
      x = 10,
      y = -4
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 589,
    name = "underground-belt",
    position = {
      x = 11,
      y = -4
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 590,
    name = "underground-belt",
    position = {
      x = 11,
      y = -3
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 591,
    name = "transport-belt",
    position = {
      x = 12,
      y = -4
    }
  },
  {
    direction = 4,
    entity_number = 592,
    name = "transport-belt",
    position = {
      x = 12,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 593,
    name = "underground-belt",
    position = {
      x = 13,
      y = -4
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 594,
    name = "underground-belt",
    position = {
      x = 14,
      y = -4
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 595,
    name = "underground-belt",
    position = {
      x = 13,
      y = -3
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 596,
    name = "transport-belt",
    position = {
      x = 14,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 597,
    name = "transport-belt",
    position = {
      x = 15,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 598,
    name = "transport-belt",
    position = {
      x = 15,
      y = -4
    }
  },
  {
    direction = 4,
    entity_number = 599,
    name = "transport-belt",
    position = {
      x = -16,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 600,
    name = "transport-belt",
    position = {
      x = -16,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 601,
    name = "transport-belt",
    position = {
      x = -15,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 602,
    name = "transport-belt",
    position = {
      x = -15,
      y = -1
    }
  },
  {
    direction = 6,
    entity_number = 603,
    name = "underground-belt",
    position = {
      x = -14,
      y = -2
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 604,
    name = "underground-belt",
    position = {
      x = -14,
      y = -1
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 605,
    name = "transport-belt",
    position = {
      x = -13,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 606,
    name = "transport-belt",
    position = {
      x = -13,
      y = -2
    }
  },
  {
    direction = 2,
    entity_number = 607,
    name = "underground-belt",
    position = {
      x = -12,
      y = -1
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 608,
    name = "transport-belt",
    position = {
      x = -12,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 609,
    name = "transport-belt",
    position = {
      x = -11,
      y = -1
    }
  },
  {
    direction = 6,
    entity_number = 610,
    name = "transport-belt",
    position = {
      x = -11,
      y = -2
    }
  },
  {
    direction = 6,
    entity_number = 611,
    name = "transport-belt",
    position = {
      x = -10,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 612,
    name = "transport-belt",
    position = {
      x = -10,
      y = -2
    }
  },
  {
    direction = 2,
    entity_number = 613,
    name = "underground-belt",
    position = {
      x = -9,
      y = -1
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 614,
    name = "underground-belt",
    position = {
      x = -9,
      y = -2
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 615,
    name = "transport-belt",
    position = {
      x = -8,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 616,
    name = "transport-belt",
    position = {
      x = -8,
      y = -1
    }
  },
  {
    direction = 6,
    entity_number = 617,
    name = "transport-belt",
    position = {
      x = -7,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 618,
    name = "underground-belt",
    position = {
      x = -7,
      y = -1
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 619,
    name = "transport-belt",
    position = {
      x = -6,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 620,
    name = "underground-belt",
    position = {
      x = -6,
      y = -1
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 621,
    name = "transport-belt",
    position = {
      x = -5,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 622,
    name = "underground-belt",
    position = {
      x = -5,
      y = -1
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 623,
    name = "transport-belt",
    position = {
      x = -4,
      y = -1
    }
  },
  {
    direction = 6,
    entity_number = 624,
    name = "transport-belt",
    position = {
      x = -4,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 625,
    name = "transport-belt",
    position = {
      x = -2,
      y = -2
    }
  },
  {
    direction = 6,
    entity_number = 626,
    name = "transport-belt",
    position = {
      x = -3,
      y = -1
    }
  },
  {
    direction = 6,
    entity_number = 627,
    name = "transport-belt",
    position = {
      x = -2,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 628,
    name = "transport-belt",
    position = {
      x = -1,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 629,
    name = "transport-belt",
    position = {
      x = -1,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 630,
    name = "transport-belt",
    position = {
      x = 0,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 631,
    name = "transport-belt",
    position = {
      x = 0,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 632,
    name = "underground-belt",
    position = {
      x = 2,
      y = -1
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 633,
    name = "underground-belt",
    position = {
      x = 2,
      y = -2
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 634,
    name = "transport-belt",
    position = {
      x = 1,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 635,
    name = "transport-belt",
    position = {
      x = 1,
      y = -2
    }
  },
  {
    direction = 2,
    entity_number = 636,
    name = "underground-belt",
    position = {
      x = 4,
      y = -1
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 637,
    name = "transport-belt",
    position = {
      x = 3,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 638,
    name = "transport-belt",
    position = {
      x = 3,
      y = -2
    }
  },
  {
    direction = 6,
    entity_number = 639,
    name = "transport-belt",
    position = {
      x = 4,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 640,
    name = "transport-belt",
    position = {
      x = 5,
      y = -1
    }
  },
  {
    direction = 6,
    entity_number = 641,
    name = "transport-belt",
    position = {
      x = 5,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 642,
    name = "transport-belt",
    position = {
      x = 6,
      y = -2
    }
  },
  {
    direction = 6,
    entity_number = 643,
    name = "transport-belt",
    position = {
      x = 6,
      y = -1
    }
  },
  {
    direction = 2,
    entity_number = 644,
    name = "underground-belt",
    position = {
      x = 7,
      y = -1
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 645,
    name = "underground-belt",
    position = {
      x = 7,
      y = -2
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 646,
    name = "transport-belt",
    position = {
      x = 8,
      y = -1
    }
  },
  {
    direction = 6,
    entity_number = 647,
    name = "transport-belt",
    position = {
      x = 8,
      y = -2
    }
  },
  {
    direction = 6,
    entity_number = 648,
    name = "transport-belt",
    position = {
      x = 9,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 649,
    name = "underground-belt",
    position = {
      x = 9,
      y = -1
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 650,
    name = "transport-belt",
    position = {
      x = 10,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 651,
    name = "underground-belt",
    position = {
      x = 10,
      y = -1
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 652,
    name = "underground-belt",
    position = {
      x = 11,
      y = -1
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 653,
    name = "transport-belt",
    position = {
      x = 11,
      y = -2
    }
  },
  {
    direction = 6,
    entity_number = 654,
    name = "transport-belt",
    position = {
      x = 12,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 655,
    name = "transport-belt",
    position = {
      x = 12,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 656,
    name = "transport-belt",
    position = {
      x = 14,
      y = -2
    }
  },
  {
    direction = 6,
    entity_number = 657,
    name = "transport-belt",
    position = {
      x = 13,
      y = -1
    }
  },
  {
    direction = 6,
    entity_number = 658,
    name = "transport-belt",
    position = {
      x = 14,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 659,
    name = "transport-belt",
    position = {
      x = 15,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 660,
    name = "transport-belt",
    position = {
      x = 15,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 661,
    name = "splitter",
    position = {
      x = -15.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 662,
    name = "transport-belt",
    position = {
      x = -16,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 663,
    name = "splitter",
    position = {
      x = -13.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 664,
    name = "transport-belt",
    position = {
      x = -15,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 665,
    name = "transport-belt",
    position = {
      x = -14,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 666,
    name = "splitter",
    position = {
      x = -11.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 667,
    name = "underground-belt",
    position = {
      x = -13,
      y = 0
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 668,
    name = "underground-belt",
    position = {
      x = -12,
      y = 0
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 669,
    name = "splitter",
    position = {
      x = -9.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 670,
    name = "transport-belt",
    position = {
      x = -11,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 671,
    name = "underground-belt",
    position = {
      x = -10,
      y = 0
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 672,
    name = "splitter",
    position = {
      x = -7.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 673,
    name = "underground-belt",
    position = {
      x = -9,
      y = 0
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 674,
    name = "transport-belt",
    position = {
      x = -8,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 675,
    name = "splitter",
    position = {
      x = -5.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 676,
    name = "transport-belt",
    position = {
      x = -7,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 677,
    name = "transport-belt",
    position = {
      x = -6,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 678,
    name = "transport-belt",
    position = {
      x = -5,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 679,
    name = "transport-belt",
    position = {
      x = -4,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 680,
    name = "splitter",
    position = {
      x = -3.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 681,
    name = "underground-belt",
    position = {
      x = -2,
      y = 0
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 682,
    name = "splitter",
    position = {
      x = -1.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 683,
    name = "underground-belt",
    position = {
      x = -3,
      y = 0
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 684,
    name = "splitter",
    position = {
      x = 0.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 685,
    name = "transport-belt",
    position = {
      x = -1,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 686,
    name = "transport-belt",
    position = {
      x = 0,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 687,
    name = "splitter",
    position = {
      x = 2.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 688,
    name = "transport-belt",
    position = {
      x = 1,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 689,
    name = "transport-belt",
    position = {
      x = 2,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 690,
    name = "underground-belt",
    position = {
      x = 3,
      y = 0
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 691,
    name = "underground-belt",
    position = {
      x = 4,
      y = 0
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 692,
    name = "splitter",
    position = {
      x = 4.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 693,
    name = "underground-belt",
    position = {
      x = 6,
      y = 0
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 694,
    name = "splitter",
    position = {
      x = 6.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 695,
    name = "transport-belt",
    position = {
      x = 5,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 696,
    name = "underground-belt",
    position = {
      x = 7,
      y = 0
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 697,
    name = "transport-belt",
    position = {
      x = 8,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 698,
    name = "splitter",
    position = {
      x = 8.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 699,
    name = "transport-belt",
    position = {
      x = 9,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 700,
    name = "transport-belt",
    position = {
      x = 10,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 701,
    name = "splitter",
    position = {
      x = 10.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 702,
    name = "transport-belt",
    position = {
      x = 11,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 703,
    name = "transport-belt",
    position = {
      x = 12,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 704,
    name = "splitter",
    position = {
      x = 12.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 705,
    name = "underground-belt",
    position = {
      x = 13,
      y = 0
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 706,
    name = "underground-belt",
    position = {
      x = 14,
      y = 0
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 707,
    name = "splitter",
    position = {
      x = 14.5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 708,
    name = "transport-belt",
    position = {
      x = 15,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 709,
    name = "transport-belt",
    position = {
      x = -16,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 710,
    name = "transport-belt",
    position = {
      x = -16,
      y = 2
    }
  },
  {
    direction = 4,
    entity_number = 711,
    name = "underground-belt",
    position = {
      x = -15,
      y = 2
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 712,
    name = "transport-belt",
    position = {
      x = -15,
      y = 3
    }
  },
  {
    direction = 6,
    entity_number = 713,
    name = "underground-belt",
    position = {
      x = -14,
      y = 3
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 714,
    name = "underground-belt",
    position = {
      x = -14,
      y = 2
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 715,
    name = "transport-belt",
    position = {
      x = -13,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 716,
    name = "transport-belt",
    position = {
      x = -13,
      y = 2
    }
  },
  {
    direction = 4,
    entity_number = 717,
    name = "transport-belt",
    position = {
      x = -12,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 718,
    name = "underground-belt",
    position = {
      x = -12,
      y = 2
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 719,
    name = "underground-belt",
    position = {
      x = -11,
      y = 3
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 720,
    name = "underground-belt",
    position = {
      x = -11,
      y = 2
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 721,
    name = "transport-belt",
    position = {
      x = -10,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 722,
    name = "underground-belt",
    position = {
      x = -10,
      y = 2
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 723,
    name = "underground-belt",
    position = {
      x = -9,
      y = 2
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 724,
    name = "transport-belt",
    position = {
      x = -9,
      y = 3
    }
  },
  {
    direction = 6,
    entity_number = 725,
    name = "transport-belt",
    position = {
      x = -8,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 726,
    name = "underground-belt",
    position = {
      x = -8,
      y = 2
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 727,
    name = "transport-belt",
    position = {
      x = -7,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 728,
    name = "underground-belt",
    position = {
      x = -7,
      y = 2
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 729,
    name = "transport-belt",
    position = {
      x = -6,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 730,
    name = "underground-belt",
    position = {
      x = -6,
      y = 2
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 731,
    name = "underground-belt",
    position = {
      x = -5,
      y = 3
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 732,
    name = "transport-belt",
    position = {
      x = -4,
      y = 2
    }
  },
  {
    direction = 4,
    entity_number = 733,
    name = "underground-belt",
    position = {
      x = -5,
      y = 2
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 734,
    name = "transport-belt",
    position = {
      x = -4,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 735,
    name = "underground-belt",
    position = {
      x = -3,
      y = 2
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 736,
    name = "underground-belt",
    position = {
      x = -2,
      y = 2
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 737,
    name = "transport-belt",
    position = {
      x = -3,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 738,
    name = "transport-belt",
    position = {
      x = -2,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 739,
    name = "underground-belt",
    position = {
      x = -1,
      y = 2
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 740,
    name = "underground-belt",
    position = {
      x = 0,
      y = 2
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 741,
    name = "underground-belt",
    position = {
      x = 0,
      y = 3
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 742,
    name = "underground-belt",
    position = {
      x = -1,
      y = 3
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 743,
    name = "underground-belt",
    position = {
      x = 2,
      y = 2
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 744,
    name = "transport-belt",
    position = {
      x = 1,
      y = 2
    }
  },
  {
    direction = 2,
    entity_number = 745,
    name = "transport-belt",
    position = {
      x = 1,
      y = 3
    }
  },
  {
    direction = 2,
    entity_number = 746,
    name = "transport-belt",
    position = {
      x = 2,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 747,
    name = "underground-belt",
    position = {
      x = 3,
      y = 2
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 748,
    name = "underground-belt",
    position = {
      x = 4,
      y = 3
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 749,
    name = "underground-belt",
    position = {
      x = 4,
      y = 2
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 750,
    name = "transport-belt",
    position = {
      x = 3,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 751,
    name = "underground-belt",
    position = {
      x = 6,
      y = 2
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 752,
    name = "underground-belt",
    position = {
      x = 5,
      y = 2
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 753,
    name = "transport-belt",
    position = {
      x = 5,
      y = 3
    }
  },
  {
    direction = 6,
    entity_number = 754,
    name = "transport-belt",
    position = {
      x = 6,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 755,
    name = "underground-belt",
    position = {
      x = 7,
      y = 2
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 756,
    name = "underground-belt",
    position = {
      x = 8,
      y = 2
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 757,
    name = "transport-belt",
    position = {
      x = 8,
      y = 3
    }
  },
  {
    direction = 6,
    entity_number = 758,
    name = "transport-belt",
    position = {
      x = 7,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 759,
    name = "underground-belt",
    position = {
      x = 10,
      y = 2
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 760,
    name = "underground-belt",
    position = {
      x = 9,
      y = 2
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 761,
    name = "transport-belt",
    position = {
      x = 9,
      y = 3
    }
  },
  {
    direction = 6,
    entity_number = 762,
    name = "transport-belt",
    position = {
      x = 10,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 763,
    name = "underground-belt",
    position = {
      x = 11,
      y = 2
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 764,
    name = "underground-belt",
    position = {
      x = 12,
      y = 2
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 765,
    name = "transport-belt",
    position = {
      x = 11,
      y = 3
    }
  },
  {
    direction = 6,
    entity_number = 766,
    name = "transport-belt",
    position = {
      x = 12,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 767,
    name = "underground-belt",
    position = {
      x = 13,
      y = 2
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 768,
    name = "transport-belt",
    position = {
      x = 13,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 769,
    name = "transport-belt",
    position = {
      x = 14,
      y = 2
    }
  },
  {
    direction = 6,
    entity_number = 770,
    name = "transport-belt",
    position = {
      x = 14,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 771,
    name = "transport-belt",
    position = {
      x = 15,
      y = 2
    }
  },
  {
    direction = 4,
    entity_number = 772,
    name = "transport-belt",
    position = {
      x = 15,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 773,
    name = "transport-belt",
    position = {
      x = -16,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 774,
    name = "transport-belt",
    position = {
      x = -16,
      y = 5
    }
  },
  {
    direction = 4,
    entity_number = 775,
    name = "underground-belt",
    position = {
      x = -15,
      y = 5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 776,
    name = "transport-belt",
    position = {
      x = -15,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 777,
    name = "underground-belt",
    position = {
      x = -14,
      y = 5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 778,
    name = "transport-belt",
    position = {
      x = -14,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 779,
    name = "transport-belt",
    position = {
      x = -13,
      y = 5
    }
  },
  {
    direction = 4,
    entity_number = 780,
    name = "transport-belt",
    position = {
      x = -13,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 781,
    name = "underground-belt",
    position = {
      x = -12,
      y = 5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 782,
    name = "transport-belt",
    position = {
      x = -12,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 783,
    name = "underground-belt",
    position = {
      x = -11,
      y = 5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 784,
    name = "transport-belt",
    position = {
      x = -11,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 785,
    name = "underground-belt",
    position = {
      x = -10,
      y = 5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 786,
    name = "transport-belt",
    position = {
      x = -10,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 787,
    name = "underground-belt",
    position = {
      x = -9,
      y = 5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 788,
    name = "transport-belt",
    position = {
      x = -9,
      y = 4
    }
  },
  {
    direction = 2,
    entity_number = 789,
    name = "transport-belt",
    position = {
      x = -8,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 790,
    name = "underground-belt",
    position = {
      x = -8,
      y = 5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 791,
    name = "underground-belt",
    position = {
      x = -7,
      y = 5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 792,
    name = "transport-belt",
    position = {
      x = -7,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 793,
    name = "underground-belt",
    position = {
      x = -6,
      y = 5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 794,
    name = "transport-belt",
    position = {
      x = -6,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 795,
    name = "underground-belt",
    position = {
      x = -5,
      y = 5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 796,
    name = "transport-belt",
    position = {
      x = -5,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 797,
    name = "transport-belt",
    position = {
      x = -4,
      y = 5
    }
  },
  {
    direction = 2,
    entity_number = 798,
    name = "transport-belt",
    position = {
      x = -4,
      y = 4
    }
  },
  {
    direction = 6,
    entity_number = 799,
    name = "underground-belt",
    position = {
      x = -3,
      y = 5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 800,
    name = "underground-belt",
    position = {
      x = -3,
      y = 4
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 801,
    name = "transport-belt",
    position = {
      x = -2,
      y = 5
    }
  },
  {
    direction = 4,
    entity_number = 802,
    name = "transport-belt",
    position = {
      x = -2,
      y = 4
    }
  },
  {
    direction = 2,
    entity_number = 803,
    name = "underground-belt",
    position = {
      x = -1,
      y = 4
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 804,
    name = "transport-belt",
    position = {
      x = -1,
      y = 5
    }
  },
  {
    direction = 2,
    entity_number = 805,
    name = "transport-belt",
    position = {
      x = 0,
      y = 5
    }
  },
  {
    direction = 2,
    entity_number = 806,
    name = "transport-belt",
    position = {
      x = 0,
      y = 4
    }
  },
  {
    direction = 2,
    entity_number = 807,
    name = "underground-belt",
    position = {
      x = 2,
      y = 4
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 808,
    name = "underground-belt",
    position = {
      x = 2,
      y = 5
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 809,
    name = "transport-belt",
    position = {
      x = 1,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 810,
    name = "transport-belt",
    position = {
      x = 1,
      y = 5
    }
  },
  {
    direction = 4,
    entity_number = 811,
    name = "underground-belt",
    position = {
      x = 4,
      y = 5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 812,
    name = "underground-belt",
    position = {
      x = 4,
      y = 4
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 813,
    name = "transport-belt",
    position = {
      x = 3,
      y = 5
    }
  },
  {
    direction = 4,
    entity_number = 814,
    name = "transport-belt",
    position = {
      x = 3,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 815,
    name = "underground-belt",
    position = {
      x = 6,
      y = 5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 816,
    name = "underground-belt",
    position = {
      x = 5,
      y = 5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 817,
    name = "transport-belt",
    position = {
      x = 5,
      y = 4
    }
  },
  {
    direction = 2,
    entity_number = 818,
    name = "transport-belt",
    position = {
      x = 6,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 819,
    name = "underground-belt",
    position = {
      x = 7,
      y = 5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 820,
    name = "underground-belt",
    position = {
      x = 8,
      y = 5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 821,
    name = "transport-belt",
    position = {
      x = 8,
      y = 4
    }
  },
  {
    direction = 2,
    entity_number = 822,
    name = "transport-belt",
    position = {
      x = 7,
      y = 4
    }
  },
  {
    direction = 2,
    entity_number = 823,
    name = "transport-belt",
    position = {
      x = 9,
      y = 4
    }
  },
  {
    direction = 2,
    entity_number = 824,
    name = "transport-belt",
    position = {
      x = 10,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 825,
    name = "underground-belt",
    position = {
      x = 9,
      y = 5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 826,
    name = "underground-belt",
    position = {
      x = 10,
      y = 5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 827,
    name = "underground-belt",
    position = {
      x = 12,
      y = 5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 828,
    name = "underground-belt",
    position = {
      x = 11,
      y = 5
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 829,
    name = "transport-belt",
    position = {
      x = 11,
      y = 4
    }
  },
  {
    direction = 2,
    entity_number = 830,
    name = "transport-belt",
    position = {
      x = 12,
      y = 4
    }
  },
  {
    direction = 2,
    entity_number = 831,
    name = "transport-belt",
    position = {
      x = 13,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 832,
    name = "transport-belt",
    position = {
      x = 14,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 833,
    name = "underground-belt",
    position = {
      x = 13,
      y = 5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 834,
    name = "transport-belt",
    position = {
      x = 14,
      y = 5
    }
  },
  {
    direction = 4,
    entity_number = 835,
    name = "transport-belt",
    position = {
      x = 15,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 836,
    name = "transport-belt",
    position = {
      x = 15,
      y = 5
    }
  },
  {
    direction = 4,
    entity_number = 837,
    name = "transport-belt",
    position = {
      x = -16,
      y = 7
    }
  },
  {
    direction = 4,
    entity_number = 838,
    name = "transport-belt",
    position = {
      x = -16,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 839,
    name = "transport-belt",
    position = {
      x = -15,
      y = 7
    }
  },
  {
    direction = 4,
    entity_number = 840,
    name = "transport-belt",
    position = {
      x = -15,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 841,
    name = "underground-belt",
    position = {
      x = -14,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 842,
    name = "transport-belt",
    position = {
      x = -14,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 843,
    name = "underground-belt",
    position = {
      x = -13,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 844,
    name = "transport-belt",
    position = {
      x = -13,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 845,
    name = "transport-belt",
    position = {
      x = -12,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 846,
    name = "underground-belt",
    position = {
      x = -12,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 847,
    name = "transport-belt",
    position = {
      x = -11,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 848,
    name = "underground-belt",
    position = {
      x = -11,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 849,
    name = "underground-belt",
    position = {
      x = -10,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 850,
    name = "transport-belt",
    position = {
      x = -10,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 851,
    name = "transport-belt",
    position = {
      x = -9,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 852,
    name = "underground-belt",
    position = {
      x = -9,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 853,
    name = "underground-belt",
    position = {
      x = -8,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 854,
    name = "transport-belt",
    position = {
      x = -8,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 855,
    name = "underground-belt",
    position = {
      x = -7,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 856,
    name = "transport-belt",
    position = {
      x = -7,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 857,
    name = "underground-belt",
    position = {
      x = -6,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 858,
    name = "transport-belt",
    position = {
      x = -6,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 859,
    name = "transport-belt",
    position = {
      x = -5,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 860,
    name = "underground-belt",
    position = {
      x = -5,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 861,
    name = "underground-belt",
    position = {
      x = -4,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 862,
    name = "transport-belt",
    position = {
      x = -4,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 863,
    name = "underground-belt",
    position = {
      x = -3,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 864,
    name = "transport-belt",
    position = {
      x = -2,
      y = 7
    }
  },
  {
    direction = 4,
    entity_number = 865,
    name = "underground-belt",
    position = {
      x = -2,
      y = 6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 866,
    name = "underground-belt",
    position = {
      x = -3,
      y = 6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 867,
    name = "underground-belt",
    position = {
      x = 0,
      y = 6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 868,
    name = "underground-belt",
    position = {
      x = -1,
      y = 6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 869,
    name = "underground-belt",
    position = {
      x = -1,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 870,
    name = "underground-belt",
    position = {
      x = 0,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 871,
    name = "underground-belt",
    position = {
      x = 2,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 872,
    name = "underground-belt",
    position = {
      x = 2,
      y = 6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 873,
    name = "underground-belt",
    position = {
      x = 1,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 874,
    name = "transport-belt",
    position = {
      x = 1,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 875,
    name = "underground-belt",
    position = {
      x = 3,
      y = 6
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 876,
    name = "underground-belt",
    position = {
      x = 4,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 877,
    name = "transport-belt",
    position = {
      x = 3,
      y = 7
    }
  },
  {
    direction = 4,
    entity_number = 878,
    name = "transport-belt",
    position = {
      x = 4,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 879,
    name = "underground-belt",
    position = {
      x = 6,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 880,
    name = "underground-belt",
    position = {
      x = 5,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 881,
    name = "transport-belt",
    position = {
      x = 5,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 882,
    name = "transport-belt",
    position = {
      x = 6,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 883,
    name = "underground-belt",
    position = {
      x = 7,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 884,
    name = "underground-belt",
    position = {
      x = 8,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 885,
    name = "transport-belt",
    position = {
      x = 7,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 886,
    name = "transport-belt",
    position = {
      x = 8,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 887,
    name = "transport-belt",
    position = {
      x = 9,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 888,
    name = "transport-belt",
    position = {
      x = 10,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 889,
    name = "underground-belt",
    position = {
      x = 10,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 890,
    name = "underground-belt",
    position = {
      x = 9,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 891,
    name = "underground-belt",
    position = {
      x = 11,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 892,
    name = "transport-belt",
    position = {
      x = 11,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 893,
    name = "transport-belt",
    position = {
      x = 12,
      y = 7
    }
  },
  {
    direction = 4,
    entity_number = 894,
    name = "transport-belt",
    position = {
      x = 12,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 895,
    name = "underground-belt",
    position = {
      x = 14,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 896,
    name = "transport-belt",
    position = {
      x = 14,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 897,
    name = "transport-belt",
    position = {
      x = 13,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 898,
    name = "underground-belt",
    position = {
      x = 13,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 899,
    name = "transport-belt",
    position = {
      x = 15,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 900,
    name = "transport-belt",
    position = {
      x = 15,
      y = 7
    }
  },
  {
    direction = 4,
    entity_number = 901,
    name = "transport-belt",
    position = {
      x = -16,
      y = 8
    }
  },
  {
    direction = 4,
    entity_number = 902,
    name = "transport-belt",
    position = {
      x = -16,
      y = 9
    }
  },
  {
    direction = 4,
    entity_number = 903,
    name = "transport-belt",
    position = {
      x = -15,
      y = 9
    }
  },
  {
    direction = 2,
    entity_number = 904,
    name = "transport-belt",
    position = {
      x = -15,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 905,
    name = "transport-belt",
    position = {
      x = -14,
      y = 9
    }
  },
  {
    direction = 2,
    entity_number = 906,
    name = "transport-belt",
    position = {
      x = -14,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 907,
    name = "transport-belt",
    position = {
      x = -13,
      y = 9
    }
  },
  {
    direction = 2,
    entity_number = 908,
    name = "transport-belt",
    position = {
      x = -13,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 909,
    name = "transport-belt",
    position = {
      x = -12,
      y = 9
    }
  },
  {
    direction = 2,
    entity_number = 910,
    name = "transport-belt",
    position = {
      x = -12,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 911,
    name = "transport-belt",
    position = {
      x = -11,
      y = 9
    }
  },
  {
    direction = 2,
    entity_number = 912,
    name = "transport-belt",
    position = {
      x = -11,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 913,
    name = "transport-belt",
    position = {
      x = -10,
      y = 9
    }
  },
  {
    direction = 2,
    entity_number = 914,
    name = "transport-belt",
    position = {
      x = -10,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 915,
    name = "transport-belt",
    position = {
      x = -9,
      y = 9
    }
  },
  {
    direction = 2,
    entity_number = 916,
    name = "transport-belt",
    position = {
      x = -9,
      y = 8
    }
  },
  {
    direction = 2,
    entity_number = 917,
    name = "transport-belt",
    position = {
      x = -8,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 918,
    name = "transport-belt",
    position = {
      x = -8,
      y = 9
    }
  },
  {
    direction = 6,
    entity_number = 919,
    name = "transport-belt",
    position = {
      x = -7,
      y = 9
    }
  },
  {
    direction = 2,
    entity_number = 920,
    name = "transport-belt",
    position = {
      x = -7,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 921,
    name = "transport-belt",
    position = {
      x = -6,
      y = 9
    }
  },
  {
    direction = 2,
    entity_number = 922,
    name = "transport-belt",
    position = {
      x = -6,
      y = 8
    }
  },
  {
    direction = 4,
    entity_number = 923,
    name = "transport-belt",
    position = {
      x = -4,
      y = 9
    }
  },
  {
    direction = 6,
    entity_number = 924,
    name = "underground-belt",
    position = {
      x = -5,
      y = 9
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 925,
    name = "transport-belt",
    position = {
      x = -4,
      y = 8
    }
  },
  {
    direction = 2,
    entity_number = 926,
    name = "underground-belt",
    position = {
      x = -5,
      y = 8
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 927,
    name = "transport-belt",
    position = {
      x = -2,
      y = 9
    }
  },
  {
    direction = 6,
    entity_number = 928,
    name = "transport-belt",
    position = {
      x = -2,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 929,
    name = "underground-belt",
    position = {
      x = -3,
      y = 9
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 930,
    name = "transport-belt",
    position = {
      x = -3,
      y = 8
    }
  },
  {
    direction = 2,
    entity_number = 931,
    name = "underground-belt",
    position = {
      x = -1,
      y = 8
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 932,
    name = "underground-belt",
    position = {
      x = 0,
      y = 9
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 933,
    name = "underground-belt",
    position = {
      x = 0,
      y = 8
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 934,
    name = "transport-belt",
    position = {
      x = -1,
      y = 9
    }
  },
  {
    direction = 6,
    entity_number = 935,
    name = "underground-belt",
    position = {
      x = 2,
      y = 9
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 936,
    name = "transport-belt",
    position = {
      x = 1,
      y = 9
    }
  },
  {
    direction = 4,
    entity_number = 937,
    name = "transport-belt",
    position = {
      x = 1,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 938,
    name = "transport-belt",
    position = {
      x = 2,
      y = 8
    }
  },
  {
    direction = 2,
    entity_number = 939,
    name = "underground-belt",
    position = {
      x = 4,
      y = 8
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 940,
    name = "transport-belt",
    position = {
      x = 3,
      y = 9
    }
  },
  {
    direction = 6,
    entity_number = 941,
    name = "transport-belt",
    position = {
      x = 3,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 942,
    name = "transport-belt",
    position = {
      x = 4,
      y = 9
    }
  },
  {
    direction = 6,
    entity_number = 943,
    name = "transport-belt",
    position = {
      x = 5,
      y = 9
    }
  },
  {
    direction = 6,
    entity_number = 944,
    name = "transport-belt",
    position = {
      x = 6,
      y = 9
    }
  },
  {
    direction = 2,
    entity_number = 945,
    name = "transport-belt",
    position = {
      x = 5,
      y = 8
    }
  },
  {
    direction = 2,
    entity_number = 946,
    name = "transport-belt",
    position = {
      x = 6,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 947,
    name = "transport-belt",
    position = {
      x = 7,
      y = 9
    }
  },
  {
    direction = 6,
    entity_number = 948,
    name = "transport-belt",
    position = {
      x = 8,
      y = 9
    }
  },
  {
    direction = 2,
    entity_number = 949,
    name = "transport-belt",
    position = {
      x = 8,
      y = 8
    }
  },
  {
    direction = 2,
    entity_number = 950,
    name = "transport-belt",
    position = {
      x = 7,
      y = 8
    }
  },
  {
    direction = 2,
    entity_number = 951,
    name = "underground-belt",
    position = {
      x = 10,
      y = 8
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 952,
    name = "transport-belt",
    position = {
      x = 9,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 953,
    name = "transport-belt",
    position = {
      x = 9,
      y = 9
    }
  },
  {
    direction = 6,
    entity_number = 954,
    name = "transport-belt",
    position = {
      x = 10,
      y = 9
    }
  },
  {
    direction = 4,
    entity_number = 955,
    name = "transport-belt",
    position = {
      x = 11,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 956,
    name = "transport-belt",
    position = {
      x = 12,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 957,
    name = "transport-belt",
    position = {
      x = 11,
      y = 9
    }
  },
  {
    direction = 4,
    entity_number = 958,
    name = "transport-belt",
    position = {
      x = 12,
      y = 9
    }
  },
  {
    direction = 2,
    entity_number = 959,
    name = "underground-belt",
    position = {
      x = 13,
      y = 8
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 960,
    name = "transport-belt",
    position = {
      x = 14,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 961,
    name = "transport-belt",
    position = {
      x = 13,
      y = 9
    }
  },
  {
    direction = 6,
    entity_number = 962,
    name = "transport-belt",
    position = {
      x = 14,
      y = 9
    }
  },
  {
    direction = 4,
    entity_number = 963,
    name = "transport-belt",
    position = {
      x = 15,
      y = 8
    }
  },
  {
    direction = 4,
    entity_number = 964,
    name = "transport-belt",
    position = {
      x = 15,
      y = 9
    }
  },
  {
    direction = 4,
    entity_number = 965,
    name = "transport-belt",
    position = {
      x = -16,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 966,
    name = "transport-belt",
    position = {
      x = -16,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 967,
    name = "underground-belt",
    position = {
      x = -14,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 968,
    name = "transport-belt",
    position = {
      x = -15,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 969,
    name = "transport-belt",
    position = {
      x = -15,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 970,
    name = "transport-belt",
    position = {
      x = -14,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 971,
    name = "underground-belt",
    position = {
      x = -13,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 972,
    name = "underground-belt",
    position = {
      x = -12,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 973,
    name = "transport-belt",
    position = {
      x = -13,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 974,
    name = "transport-belt",
    position = {
      x = -12,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 975,
    name = "underground-belt",
    position = {
      x = -11,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 976,
    name = "transport-belt",
    position = {
      x = -11,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 977,
    name = "transport-belt",
    position = {
      x = -10,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 978,
    name = "underground-belt",
    position = {
      x = -10,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 979,
    name = "underground-belt",
    position = {
      x = -8,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 980,
    name = "transport-belt",
    position = {
      x = -9,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 981,
    name = "underground-belt",
    position = {
      x = -9,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 982,
    name = "transport-belt",
    position = {
      x = -8,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 983,
    name = "underground-belt",
    position = {
      x = -7,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 984,
    name = "transport-belt",
    position = {
      x = -7,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 985,
    name = "transport-belt",
    position = {
      x = -6,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 986,
    name = "underground-belt",
    position = {
      x = -6,
      y = 10
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 987,
    name = "transport-belt",
    position = {
      x = -4,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 988,
    name = "underground-belt",
    position = {
      x = -4,
      y = 11
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 989,
    name = "transport-belt",
    position = {
      x = -5,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 990,
    name = "underground-belt",
    position = {
      x = -5,
      y = 10
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 991,
    name = "underground-belt",
    position = {
      x = -3,
      y = 10
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 992,
    name = "underground-belt",
    position = {
      x = -3,
      y = 11
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 993,
    name = "transport-belt",
    position = {
      x = -2,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 994,
    name = "transport-belt",
    position = {
      x = -2,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 995,
    name = "underground-belt",
    position = {
      x = -1,
      y = 11
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 996,
    name = "transport-belt",
    position = {
      x = -1,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 997,
    name = "underground-belt",
    position = {
      x = 0,
      y = 11
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 998,
    name = "transport-belt",
    position = {
      x = 0,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 999,
    name = "underground-belt",
    position = {
      x = 1,
      y = 11
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1000,
    name = "underground-belt",
    position = {
      x = 2,
      y = 11
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1001,
    name = "underground-belt",
    position = {
      x = 2,
      y = 10
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 1002,
    name = "transport-belt",
    position = {
      x = 1,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 1003,
    name = "underground-belt",
    position = {
      x = 4,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1004,
    name = "transport-belt",
    position = {
      x = 3,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 1005,
    name = "transport-belt",
    position = {
      x = 4,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 1006,
    name = "transport-belt",
    position = {
      x = 3,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 1007,
    name = "underground-belt",
    position = {
      x = 6,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1008,
    name = "underground-belt",
    position = {
      x = 5,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1009,
    name = "transport-belt",
    position = {
      x = 5,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 1010,
    name = "transport-belt",
    position = {
      x = 6,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 1011,
    name = "underground-belt",
    position = {
      x = 8,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1012,
    name = "underground-belt",
    position = {
      x = 7,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1013,
    name = "transport-belt",
    position = {
      x = 7,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 1014,
    name = "transport-belt",
    position = {
      x = 8,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 1015,
    name = "underground-belt",
    position = {
      x = 10,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1016,
    name = "underground-belt",
    position = {
      x = 9,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1017,
    name = "transport-belt",
    position = {
      x = 10,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 1018,
    name = "transport-belt",
    position = {
      x = 9,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 1019,
    name = "underground-belt",
    position = {
      x = 11,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1020,
    name = "transport-belt",
    position = {
      x = 12,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 1021,
    name = "transport-belt",
    position = {
      x = 11,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 1022,
    name = "transport-belt",
    position = {
      x = 12,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 1023,
    name = "underground-belt",
    position = {
      x = 13,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1024,
    name = "underground-belt",
    position = {
      x = 14,
      y = 10
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1025,
    name = "transport-belt",
    position = {
      x = 13,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 1026,
    name = "transport-belt",
    position = {
      x = 14,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 1027,
    name = "transport-belt",
    position = {
      x = 15,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 1028,
    name = "transport-belt",
    position = {
      x = 15,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 1029,
    name = "transport-belt",
    position = {
      x = -16,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1030,
    name = "transport-belt",
    position = {
      x = -16,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 1031,
    name = "transport-belt",
    position = {
      x = -15,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1032,
    name = "transport-belt",
    position = {
      x = -14,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1033,
    name = "transport-belt",
    position = {
      x = -15,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 1034,
    name = "transport-belt",
    position = {
      x = -14,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 1035,
    name = "transport-belt",
    position = {
      x = -12,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 1036,
    name = "transport-belt",
    position = {
      x = -13,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1037,
    name = "transport-belt",
    position = {
      x = -13,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 1038,
    name = "transport-belt",
    position = {
      x = -12,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1039,
    name = "underground-belt",
    position = {
      x = -11,
      y = 12
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1040,
    name = "underground-belt",
    position = {
      x = -10,
      y = 12
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1041,
    name = "transport-belt",
    position = {
      x = -11,
      y = 13
    }
  },
  {
    direction = 6,
    entity_number = 1042,
    name = "underground-belt",
    position = {
      x = -10,
      y = 13
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1043,
    name = "transport-belt",
    position = {
      x = -9,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1044,
    name = "transport-belt",
    position = {
      x = -9,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 1045,
    name = "transport-belt",
    position = {
      x = -8,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1046,
    name = "underground-belt",
    position = {
      x = -8,
      y = 12
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 1047,
    name = "underground-belt",
    position = {
      x = -7,
      y = 13
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1048,
    name = "underground-belt",
    position = {
      x = -7,
      y = 12
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 1049,
    name = "underground-belt",
    position = {
      x = -6,
      y = 13
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1050,
    name = "underground-belt",
    position = {
      x = -6,
      y = 12
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1051,
    name = "underground-belt",
    position = {
      x = -4,
      y = 12
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1052,
    name = "transport-belt",
    position = {
      x = -5,
      y = 12
    }
  },
  {
    direction = 6,
    entity_number = 1053,
    name = "underground-belt",
    position = {
      x = -4,
      y = 13
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1054,
    name = "transport-belt",
    position = {
      x = -5,
      y = 13
    }
  },
  {
    direction = 6,
    entity_number = 1055,
    name = "underground-belt",
    position = {
      x = -3,
      y = 13
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1056,
    name = "transport-belt",
    position = {
      x = -2,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1057,
    name = "underground-belt",
    position = {
      x = -2,
      y = 12
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1058,
    name = "underground-belt",
    position = {
      x = -3,
      y = 12
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1059,
    name = "underground-belt",
    position = {
      x = -1,
      y = 12
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 1060,
    name = "transport-belt",
    position = {
      x = -1,
      y = 13
    }
  },
  {
    direction = 2,
    entity_number = 1061,
    name = "transport-belt",
    position = {
      x = 0,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1062,
    name = "underground-belt",
    position = {
      x = 0,
      y = 12
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 1063,
    name = "underground-belt",
    position = {
      x = 2,
      y = 13
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1064,
    name = "underground-belt",
    position = {
      x = 1,
      y = 12
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1065,
    name = "underground-belt",
    position = {
      x = 2,
      y = 12
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1066,
    name = "transport-belt",
    position = {
      x = 1,
      y = 13
    }
  },
  {
    direction = 6,
    entity_number = 1067,
    name = "underground-belt",
    position = {
      x = 3,
      y = 13
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1068,
    name = "underground-belt",
    position = {
      x = 4,
      y = 13
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1069,
    name = "underground-belt",
    position = {
      x = 3,
      y = 12
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1070,
    name = "transport-belt",
    position = {
      x = 4,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 1071,
    name = "underground-belt",
    position = {
      x = 5,
      y = 13
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 1072,
    name = "transport-belt",
    position = {
      x = 6,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1073,
    name = "transport-belt",
    position = {
      x = 5,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 1074,
    name = "transport-belt",
    position = {
      x = 6,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 1075,
    name = "underground-belt",
    position = {
      x = 7,
      y = 12
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1076,
    name = "underground-belt",
    position = {
      x = 8,
      y = 12
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 1077,
    name = "underground-belt",
    position = {
      x = 8,
      y = 13
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1078,
    name = "transport-belt",
    position = {
      x = 7,
      y = 13
    }
  },
  {
    direction = 6,
    entity_number = 1079,
    name = "transport-belt",
    position = {
      x = 9,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1080,
    name = "underground-belt",
    position = {
      x = 9,
      y = 12
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1081,
    name = "transport-belt",
    position = {
      x = 10,
      y = 12
    }
  },
  {
    direction = 6,
    entity_number = 1082,
    name = "transport-belt",
    position = {
      x = 10,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1083,
    name = "transport-belt",
    position = {
      x = 11,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 1084,
    name = "transport-belt",
    position = {
      x = 12,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 1085,
    name = "transport-belt",
    position = {
      x = 11,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1086,
    name = "transport-belt",
    position = {
      x = 12,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1087,
    name = "transport-belt",
    position = {
      x = 13,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1088,
    name = "transport-belt",
    position = {
      x = 13,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 1089,
    name = "transport-belt",
    position = {
      x = 14,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 1090,
    name = "transport-belt",
    position = {
      x = 14,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1091,
    name = "transport-belt",
    position = {
      x = 15,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 1092,
    name = "transport-belt",
    position = {
      x = 15,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 1093,
    name = "transport-belt",
    position = {
      x = -16,
      y = 15
    }
  },
  {
    direction = 4,
    entity_number = 1094,
    name = "transport-belt",
    position = {
      x = -16,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1095,
    name = "transport-belt",
    position = {
      x = -15,
      y = 15
    }
  },
  {
    direction = 4,
    entity_number = 1096,
    name = "transport-belt",
    position = {
      x = -15,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1097,
    name = "transport-belt",
    position = {
      x = -14,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1098,
    name = "transport-belt",
    position = {
      x = -14,
      y = 15
    }
  },
  {
    direction = 4,
    entity_number = 1099,
    name = "transport-belt",
    position = {
      x = -13,
      y = 15
    }
  },
  {
    direction = 4,
    entity_number = 1100,
    name = "transport-belt",
    position = {
      x = -13,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1101,
    name = "transport-belt",
    position = {
      x = -12,
      y = 15
    }
  },
  {
    direction = 4,
    entity_number = 1102,
    name = "transport-belt",
    position = {
      x = -12,
      y = 14
    }
  },
  {
    direction = 2,
    entity_number = 1103,
    name = "transport-belt",
    position = {
      x = -10,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1104,
    name = "underground-belt",
    position = {
      x = -11,
      y = 15
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1105,
    name = "underground-belt",
    position = {
      x = -10,
      y = 15
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1106,
    name = "transport-belt",
    position = {
      x = -11,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1107,
    name = "transport-belt",
    position = {
      x = -9,
      y = 15
    }
  },
  {
    direction = 4,
    entity_number = 1108,
    name = "underground-belt",
    position = {
      x = -8,
      y = 15
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1109,
    name = "transport-belt",
    position = {
      x = -9,
      y = 14
    }
  },
  {
    direction = 2,
    entity_number = 1110,
    name = "transport-belt",
    position = {
      x = -8,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1111,
    name = "underground-belt",
    position = {
      x = -7,
      y = 15
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1112,
    name = "transport-belt",
    position = {
      x = -7,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1113,
    name = "underground-belt",
    position = {
      x = -6,
      y = 15
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1114,
    name = "underground-belt",
    position = {
      x = -6,
      y = 14
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 1115,
    name = "transport-belt",
    position = {
      x = -5,
      y = 14
    }
  },
  {
    direction = 2,
    entity_number = 1116,
    name = "transport-belt",
    position = {
      x = -4,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1117,
    name = "transport-belt",
    position = {
      x = -5,
      y = 15
    }
  },
  {
    direction = 6,
    entity_number = 1118,
    name = "transport-belt",
    position = {
      x = -4,
      y = 15
    }
  },
  {
    direction = 6,
    entity_number = 1119,
    name = "transport-belt",
    position = {
      x = -3,
      y = 15
    }
  },
  {
    direction = 2,
    entity_number = 1120,
    name = "transport-belt",
    position = {
      x = -3,
      y = 14
    }
  },
  {
    direction = 6,
    entity_number = 1121,
    name = "transport-belt",
    position = {
      x = -2,
      y = 15
    }
  },
  {
    entity_number = 1122,
    name = "transport-belt",
    position = {
      x = -2,
      y = 14
    }
  },
  {
    direction = 2,
    entity_number = 1123,
    name = "underground-belt",
    position = {
      x = -1,
      y = 14
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 1124,
    name = "transport-belt",
    position = {
      x = -1,
      y = 15
    }
  },
  {
    direction = 6,
    entity_number = 1125,
    name = "transport-belt",
    position = {
      x = 0,
      y = 15
    }
  },
  {
    direction = 2,
    entity_number = 1126,
    name = "underground-belt",
    position = {
      x = 0,
      y = 14
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 1127,
    name = "underground-belt",
    position = {
      x = 2,
      y = 15
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 1128,
    name = "transport-belt",
    position = {
      x = 1,
      y = 15
    }
  },
  {
    direction = 2,
    entity_number = 1129,
    name = "transport-belt",
    position = {
      x = 1,
      y = 14
    }
  },
  {
    direction = 2,
    entity_number = 1130,
    name = "transport-belt",
    position = {
      x = 2,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1131,
    name = "underground-belt",
    position = {
      x = 3,
      y = 15
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1132,
    name = "transport-belt",
    position = {
      x = 4,
      y = 15
    }
  },
  {
    direction = 2,
    entity_number = 1133,
    name = "transport-belt",
    position = {
      x = 3,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1134,
    name = "transport-belt",
    position = {
      x = 4,
      y = 14
    }
  },
  {
    direction = 2,
    entity_number = 1135,
    name = "underground-belt",
    position = {
      x = 6,
      y = 14
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 1136,
    name = "underground-belt",
    position = {
      x = 5,
      y = 14
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1137,
    name = "transport-belt",
    position = {
      x = 5,
      y = 15
    }
  },
  {
    direction = 4,
    entity_number = 1138,
    name = "transport-belt",
    position = {
      x = 6,
      y = 15
    }
  },
  {
    direction = 2,
    entity_number = 1139,
    name = "transport-belt",
    position = {
      x = 7,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1140,
    name = "transport-belt",
    position = {
      x = 8,
      y = 14
    }
  },
  {
    direction = 6,
    entity_number = 1141,
    name = "underground-belt",
    position = {
      x = 7,
      y = 15
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 1142,
    name = "transport-belt",
    position = {
      x = 8,
      y = 15
    }
  },
  {
    direction = 2,
    entity_number = 1143,
    name = "underground-belt",
    position = {
      x = 9,
      y = 14
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1144,
    name = "transport-belt",
    position = {
      x = 10,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1145,
    name = "underground-belt",
    position = {
      x = 9,
      y = 15
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1146,
    name = "transport-belt",
    position = {
      x = 10,
      y = 15
    }
  },
  {
    direction = 4,
    entity_number = 1147,
    name = "transport-belt",
    position = {
      x = 12,
      y = 15
    }
  },
  {
    direction = 4,
    entity_number = 1148,
    name = "transport-belt",
    position = {
      x = 11,
      y = 15
    }
  },
  {
    direction = 4,
    entity_number = 1149,
    name = "transport-belt",
    position = {
      x = 11,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1150,
    name = "transport-belt",
    position = {
      x = 12,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1151,
    name = "transport-belt",
    position = {
      x = 13,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1152,
    name = "transport-belt",
    position = {
      x = 13,
      y = 15
    }
  },
  {
    direction = 4,
    entity_number = 1153,
    name = "transport-belt",
    position = {
      x = 14,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1154,
    name = "transport-belt",
    position = {
      x = 14,
      y = 15
    }
  },
  {
    direction = 4,
    entity_number = 1155,
    name = "transport-belt",
    position = {
      x = 15,
      y = 14
    }
  },
  {
    direction = 4,
    entity_number = 1156,
    name = "transport-belt",
    position = {
      x = 15,
      y = 15
    }
  },
  {
    direction = 4,
    entity_number = 1157,
    name = "transport-belt",
    position = {
      x = -16,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1158,
    name = "transport-belt",
    position = {
      x = -16,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1159,
    name = "transport-belt",
    position = {
      x = -15,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1160,
    name = "transport-belt",
    position = {
      x = -14,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1161,
    name = "transport-belt",
    position = {
      x = -15,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1162,
    name = "transport-belt",
    position = {
      x = -14,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1163,
    name = "transport-belt",
    position = {
      x = -13,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1164,
    name = "transport-belt",
    position = {
      x = -13,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1165,
    name = "transport-belt",
    position = {
      x = -12,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1166,
    name = "transport-belt",
    position = {
      x = -12,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1167,
    name = "transport-belt",
    position = {
      x = -11,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1168,
    name = "transport-belt",
    position = {
      x = -11,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1169,
    name = "underground-belt",
    position = {
      x = -10,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1170,
    name = "transport-belt",
    position = {
      x = -10,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1171,
    name = "underground-belt",
    position = {
      x = -9,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1172,
    name = "transport-belt",
    position = {
      x = -9,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1173,
    name = "underground-belt",
    position = {
      x = -8,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1174,
    name = "transport-belt",
    position = {
      x = -8,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1175,
    name = "transport-belt",
    position = {
      x = -7,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1176,
    name = "transport-belt",
    position = {
      x = -7,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1177,
    name = "transport-belt",
    position = {
      x = -6,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1178,
    name = "transport-belt",
    position = {
      x = -6,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1179,
    name = "transport-belt",
    position = {
      x = -5,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1180,
    name = "transport-belt",
    position = {
      x = -5,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1181,
    name = "underground-belt",
    position = {
      x = -4,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1182,
    name = "underground-belt",
    position = {
      x = -4,
      y = 16
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1183,
    name = "underground-belt",
    position = {
      x = -3,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1184,
    name = "underground-belt",
    position = {
      x = -2,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1185,
    name = "underground-belt",
    position = {
      x = -2,
      y = 16
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1186,
    name = "underground-belt",
    position = {
      x = -3,
      y = 16
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1187,
    name = "underground-belt",
    position = {
      x = -1,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1188,
    name = "underground-belt",
    position = {
      x = -1,
      y = 16
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1189,
    name = "underground-belt",
    position = {
      x = 0,
      y = 16
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1190,
    name = "underground-belt",
    position = {
      x = 0,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1191,
    name = "underground-belt",
    position = {
      x = 1,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1192,
    name = "underground-belt",
    position = {
      x = 2,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1193,
    name = "underground-belt",
    position = {
      x = 1,
      y = 16
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1194,
    name = "underground-belt",
    position = {
      x = 2,
      y = 16
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1195,
    name = "underground-belt",
    position = {
      x = 3,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1196,
    name = "underground-belt",
    position = {
      x = 4,
      y = 16
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1197,
    name = "transport-belt",
    position = {
      x = 4,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1198,
    name = "transport-belt",
    position = {
      x = 3,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1199,
    name = "underground-belt",
    position = {
      x = 6,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1200,
    name = "underground-belt",
    position = {
      x = 5,
      y = 16
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1201,
    name = "underground-belt",
    position = {
      x = 5,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1202,
    name = "transport-belt",
    position = {
      x = 6,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1203,
    name = "underground-belt",
    position = {
      x = 8,
      y = 16
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1204,
    name = "underground-belt",
    position = {
      x = 7,
      y = 16
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1205,
    name = "underground-belt",
    position = {
      x = 7,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1206,
    name = "transport-belt",
    position = {
      x = 8,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1207,
    name = "transport-belt",
    position = {
      x = 9,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1208,
    name = "transport-belt",
    position = {
      x = 10,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1209,
    name = "underground-belt",
    position = {
      x = 9,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1210,
    name = "underground-belt",
    position = {
      x = 10,
      y = 17
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1211,
    name = "transport-belt",
    position = {
      x = 11,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1212,
    name = "transport-belt",
    position = {
      x = 12,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1213,
    name = "transport-belt",
    position = {
      x = 12,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1214,
    name = "transport-belt",
    position = {
      x = 11,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1215,
    name = "transport-belt",
    position = {
      x = 13,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1216,
    name = "transport-belt",
    position = {
      x = 14,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1217,
    name = "transport-belt",
    position = {
      x = 13,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1218,
    name = "transport-belt",
    position = {
      x = 14,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1219,
    name = "transport-belt",
    position = {
      x = 15,
      y = 16
    }
  },
  {
    direction = 4,
    entity_number = 1220,
    name = "transport-belt",
    position = {
      x = 15,
      y = 17
    }
  },
  {
    direction = 4,
    entity_number = 1221,
    name = "transport-belt",
    position = {
      x = -16,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1222,
    name = "transport-belt",
    position = {
      x = -16,
      y = 18
    }
  },
  {
    direction = 4,
    entity_number = 1223,
    name = "transport-belt",
    position = {
      x = -15,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1224,
    name = "transport-belt",
    position = {
      x = -15,
      y = 18
    }
  },
  {
    direction = 4,
    entity_number = 1225,
    name = "transport-belt",
    position = {
      x = -14,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1226,
    name = "transport-belt",
    position = {
      x = -14,
      y = 18
    }
  },
  {
    direction = 4,
    entity_number = 1227,
    name = "transport-belt",
    position = {
      x = -13,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1228,
    name = "transport-belt",
    position = {
      x = -12,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1229,
    name = "transport-belt",
    position = {
      x = -13,
      y = 18
    }
  },
  {
    direction = 4,
    entity_number = 1230,
    name = "transport-belt",
    position = {
      x = -12,
      y = 18
    }
  },
  {
    direction = 4,
    entity_number = 1231,
    name = "transport-belt",
    position = {
      x = -11,
      y = 19
    }
  },
  {
    direction = 2,
    entity_number = 1232,
    name = "transport-belt",
    position = {
      x = -11,
      y = 18
    }
  },
  {
    direction = 6,
    entity_number = 1233,
    name = "underground-belt",
    position = {
      x = -10,
      y = 19
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1234,
    name = "transport-belt",
    position = {
      x = -10,
      y = 18
    }
  },
  {
    direction = 4,
    entity_number = 1235,
    name = "transport-belt",
    position = {
      x = -9,
      y = 19
    }
  },
  {
    direction = 2,
    entity_number = 1236,
    name = "underground-belt",
    position = {
      x = -9,
      y = 18
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1237,
    name = "transport-belt",
    position = {
      x = -8,
      y = 18
    }
  },
  {
    direction = 6,
    entity_number = 1238,
    name = "transport-belt",
    position = {
      x = -8,
      y = 19
    }
  },
  {
    direction = 6,
    entity_number = 1239,
    name = "underground-belt",
    position = {
      x = -7,
      y = 19
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 1240,
    name = "transport-belt",
    position = {
      x = -7,
      y = 18
    }
  },
  {
    direction = 6,
    entity_number = 1241,
    name = "underground-belt",
    position = {
      x = -6,
      y = 19
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1242,
    name = "underground-belt",
    position = {
      x = -6,
      y = 18
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1243,
    name = "transport-belt",
    position = {
      x = -5,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1244,
    name = "underground-belt",
    position = {
      x = -5,
      y = 18
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 1245,
    name = "underground-belt",
    position = {
      x = -4,
      y = 18
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 1246,
    name = "transport-belt",
    position = {
      x = -4,
      y = 19
    }
  },
  {
    direction = 2,
    entity_number = 1247,
    name = "underground-belt",
    position = {
      x = -3,
      y = 18
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 1248,
    name = "transport-belt",
    position = {
      x = -3,
      y = 19
    }
  },
  {
    direction = 6,
    entity_number = 1249,
    name = "transport-belt",
    position = {
      x = -2,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1250,
    name = "transport-belt",
    position = {
      x = -2,
      y = 18
    }
  },
  {
    direction = 6,
    entity_number = 1251,
    name = "underground-belt",
    position = {
      x = 0,
      y = 19
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 1252,
    name = "transport-belt",
    position = {
      x = -1,
      y = 18
    }
  },
  {
    direction = 6,
    entity_number = 1253,
    name = "transport-belt",
    position = {
      x = 0,
      y = 18
    }
  },
  {
    direction = 6,
    entity_number = 1254,
    name = "underground-belt",
    position = {
      x = -1,
      y = 19
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 1255,
    name = "underground-belt",
    position = {
      x = 2,
      y = 18
    },
    type = "output"
  },
  {
    entity_number = 1256,
    name = "transport-belt",
    position = {
      x = 1,
      y = 19
    }
  },
  {
    direction = 6,
    entity_number = 1257,
    name = "transport-belt",
    position = {
      x = 1,
      y = 18
    }
  },
  {
    direction = 6,
    entity_number = 1258,
    name = "transport-belt",
    position = {
      x = 2,
      y = 19
    }
  },
  {
    direction = 2,
    entity_number = 1259,
    name = "underground-belt",
    position = {
      x = 3,
      y = 18
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 1260,
    name = "transport-belt",
    position = {
      x = 3,
      y = 19
    }
  },
  {
    direction = 6,
    entity_number = 1261,
    name = "transport-belt",
    position = {
      x = 4,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1262,
    name = "transport-belt",
    position = {
      x = 4,
      y = 18
    }
  },
  {
    direction = 6,
    entity_number = 1263,
    name = "underground-belt",
    position = {
      x = 5,
      y = 19
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 1264,
    name = "underground-belt",
    position = {
      x = 6,
      y = 18
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 1265,
    name = "underground-belt",
    position = {
      x = 5,
      y = 18
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 1266,
    name = "transport-belt",
    position = {
      x = 6,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1267,
    name = "transport-belt",
    position = {
      x = 7,
      y = 18
    }
  },
  {
    direction = 6,
    entity_number = 1268,
    name = "transport-belt",
    position = {
      x = 8,
      y = 18
    }
  },
  {
    direction = 6,
    entity_number = 1269,
    name = "transport-belt",
    position = {
      x = 7,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1270,
    name = "transport-belt",
    position = {
      x = 8,
      y = 19
    }
  },
  {
    direction = 2,
    entity_number = 1271,
    name = "underground-belt",
    position = {
      x = 9,
      y = 18
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1272,
    name = "transport-belt",
    position = {
      x = 10,
      y = 18
    }
  },
  {
    direction = 6,
    entity_number = 1273,
    name = "transport-belt",
    position = {
      x = 9,
      y = 19
    }
  },
  {
    direction = 6,
    entity_number = 1274,
    name = "transport-belt",
    position = {
      x = 10,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1275,
    name = "transport-belt",
    position = {
      x = 12,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1276,
    name = "transport-belt",
    position = {
      x = 11,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1277,
    name = "transport-belt",
    position = {
      x = 11,
      y = 18
    }
  },
  {
    direction = 4,
    entity_number = 1278,
    name = "transport-belt",
    position = {
      x = 12,
      y = 18
    }
  },
  {
    direction = 4,
    entity_number = 1279,
    name = "transport-belt",
    position = {
      x = 13,
      y = 18
    }
  },
  {
    direction = 4,
    entity_number = 1280,
    name = "transport-belt",
    position = {
      x = 14,
      y = 18
    }
  },
  {
    direction = 4,
    entity_number = 1281,
    name = "transport-belt",
    position = {
      x = 13,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1282,
    name = "transport-belt",
    position = {
      x = 14,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1283,
    name = "transport-belt",
    position = {
      x = 15,
      y = 18
    }
  },
  {
    direction = 4,
    entity_number = 1284,
    name = "transport-belt",
    position = {
      x = 15,
      y = 19
    }
  },
  {
    direction = 4,
    entity_number = 1285,
    name = "transport-belt",
    position = {
      x = -16,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1286,
    name = "transport-belt",
    position = {
      x = -16,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1287,
    name = "transport-belt",
    position = {
      x = -15,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1288,
    name = "transport-belt",
    position = {
      x = -15,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1289,
    name = "transport-belt",
    position = {
      x = -14,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1290,
    name = "transport-belt",
    position = {
      x = -14,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1291,
    name = "transport-belt",
    position = {
      x = -13,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1292,
    name = "transport-belt",
    position = {
      x = -12,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1293,
    name = "transport-belt",
    position = {
      x = -13,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1294,
    name = "transport-belt",
    position = {
      x = -12,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1295,
    name = "transport-belt",
    position = {
      x = -11,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1296,
    name = "transport-belt",
    position = {
      x = -10,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1297,
    name = "transport-belt",
    position = {
      x = -11,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1298,
    name = "underground-belt",
    position = {
      x = -10,
      y = 20
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1299,
    name = "underground-belt",
    position = {
      x = -9,
      y = 21
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1300,
    name = "underground-belt",
    position = {
      x = -8,
      y = 21
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1301,
    name = "transport-belt",
    position = {
      x = -9,
      y = 20
    }
  },
  {
    direction = 2,
    entity_number = 1302,
    name = "underground-belt",
    position = {
      x = -8,
      y = 20
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 1303,
    name = "transport-belt",
    position = {
      x = -7,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1304,
    name = "transport-belt",
    position = {
      x = -7,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1305,
    name = "underground-belt",
    position = {
      x = -6,
      y = 21
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 1306,
    name = "transport-belt",
    position = {
      x = -6,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1307,
    name = "underground-belt",
    position = {
      x = -5,
      y = 21
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 1308,
    name = "transport-belt",
    position = {
      x = -5,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1309,
    name = "transport-belt",
    position = {
      x = -4,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1310,
    name = "underground-belt",
    position = {
      x = -4,
      y = 20
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1311,
    name = "underground-belt",
    position = {
      x = -3,
      y = 21
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1312,
    name = "underground-belt",
    position = {
      x = -3,
      y = 20
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1313,
    name = "transport-belt",
    position = {
      x = -2,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1314,
    name = "underground-belt",
    position = {
      x = -2,
      y = 21
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1315,
    name = "transport-belt",
    position = {
      x = -1,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1316,
    name = "underground-belt",
    position = {
      x = -1,
      y = 21
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1317,
    name = "transport-belt",
    position = {
      x = 0,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1318,
    name = "underground-belt",
    position = {
      x = 0,
      y = 21
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1319,
    name = "underground-belt",
    position = {
      x = 2,
      y = 21
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1320,
    name = "underground-belt",
    position = {
      x = 1,
      y = 21
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 1321,
    name = "transport-belt",
    position = {
      x = 1,
      y = 20
    }
  },
  {
    direction = 2,
    entity_number = 1322,
    name = "transport-belt",
    position = {
      x = 2,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1323,
    name = "underground-belt",
    position = {
      x = 3,
      y = 21
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1324,
    name = "transport-belt",
    position = {
      x = 4,
      y = 21
    }
  },
  {
    direction = 2,
    entity_number = 1325,
    name = "transport-belt",
    position = {
      x = 3,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1326,
    name = "transport-belt",
    position = {
      x = 4,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1327,
    name = "underground-belt",
    position = {
      x = 6,
      y = 20
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1328,
    name = "underground-belt",
    position = {
      x = 5,
      y = 20
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1329,
    name = "transport-belt",
    position = {
      x = 5,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1330,
    name = "transport-belt",
    position = {
      x = 6,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1331,
    name = "underground-belt",
    position = {
      x = 7,
      y = 20
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1332,
    name = "transport-belt",
    position = {
      x = 8,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1333,
    name = "transport-belt",
    position = {
      x = 8,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1334,
    name = "transport-belt",
    position = {
      x = 7,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1335,
    name = "underground-belt",
    position = {
      x = 10,
      y = 20
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1336,
    name = "underground-belt",
    position = {
      x = 9,
      y = 20
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 1337,
    name = "transport-belt",
    position = {
      x = 9,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1338,
    name = "transport-belt",
    position = {
      x = 10,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1339,
    name = "transport-belt",
    position = {
      x = 11,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1340,
    name = "transport-belt",
    position = {
      x = 11,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1341,
    name = "transport-belt",
    position = {
      x = 12,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1342,
    name = "transport-belt",
    position = {
      x = 12,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1343,
    name = "transport-belt",
    position = {
      x = 13,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1344,
    name = "transport-belt",
    position = {
      x = 14,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1345,
    name = "transport-belt",
    position = {
      x = 13,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1346,
    name = "transport-belt",
    position = {
      x = 14,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1347,
    name = "transport-belt",
    position = {
      x = 15,
      y = 20
    }
  },
  {
    direction = 4,
    entity_number = 1348,
    name = "transport-belt",
    position = {
      x = 15,
      y = 21
    }
  },
  {
    direction = 4,
    entity_number = 1349,
    name = "splitter",
    position = {
      x = -15.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1350,
    name = "splitter",
    position = {
      x = -13.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1351,
    name = "splitter",
    position = {
      x = -11.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1352,
    name = "splitter",
    position = {
      x = -9.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1353,
    name = "splitter",
    position = {
      x = -7.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1354,
    name = "splitter",
    position = {
      x = -5.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1355,
    name = "splitter",
    position = {
      x = -3.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1356,
    name = "splitter",
    position = {
      x = -1.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1357,
    name = "splitter",
    position = {
      x = 0.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1358,
    name = "splitter",
    position = {
      x = 2.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1359,
    name = "splitter",
    position = {
      x = 4.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1360,
    name = "splitter",
    position = {
      x = 6.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1361,
    name = "splitter",
    position = {
      x = 8.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1362,
    name = "splitter",
    position = {
      x = 10.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1363,
    name = "splitter",
    position = {
      x = 12.5,
      y = 22
    }
  },
  {
    direction = 4,
    entity_number = 1364,
    name = "splitter",
    position = {
      x = 14.5,
      y = 22
    }
  }
}