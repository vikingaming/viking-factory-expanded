return {
  {
    entity_number = 1,
    name = "transport-belt",
    position = {
      x = 0,
      y = -2
    }
  },
  {
    entity_number = 2,
    name = "splitter",
    position = {
      x = -0.5,
      y = -1
    }
  },
  {
    entity_number = 3,
    name = "transport-belt",
    position = {
      x = -2,
      y = 1
    }
  },
  {
    entity_number = 4,
    name = "splitter",
    position = {
      x = -1.5,
      y = 0
    }
  },
  {
    entity_number = 5,
    name = "transport-belt",
    position = {
      x = 0,
      y = 1
    }
  },
  {
    entity_number = 6,
    name = "transport-belt",
    position = {
      x = -1,
      y = 1
    }
  },
  {
    entity_number = 7,
    name = "splitter",
    position = {
      x = 0.5,
      y = 0
    }
  },
  {
    entity_number = 8,
    name = "transport-belt",
    position = {
      x = 1,
      y = 1
    }
  }
}