return {
  {
    direction = 4,
    entity_number = 1,
    name = "splitter",
    position = {
      x = -8.5,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 2,
    name = "transport-belt",
    position = {
      x = -8,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 3,
    name = "transport-belt",
    position = {
      x = -9,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 4,
    name = "splitter",
    position = {
      x = -6.5,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 5,
    name = "transport-belt",
    position = {
      x = -6,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 6,
    name = "transport-belt",
    position = {
      x = -7,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 7,
    name = "splitter",
    position = {
      x = -4.5,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 8,
    name = "transport-belt",
    position = {
      x = -4,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 9,
    name = "transport-belt",
    position = {
      x = -5,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 10,
    name = "splitter",
    position = {
      x = -2.5,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 11,
    name = "transport-belt",
    position = {
      x = -2,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 12,
    name = "transport-belt",
    position = {
      x = -3,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 13,
    name = "splitter",
    position = {
      x = 1.5,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 14,
    name = "transport-belt",
    position = {
      x = 2,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 15,
    name = "transport-belt",
    position = {
      x = 1,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 16,
    name = "splitter",
    position = {
      x = 3.5,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 17,
    name = "transport-belt",
    position = {
      x = 4,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 18,
    name = "transport-belt",
    position = {
      x = 3,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 19,
    name = "splitter",
    position = {
      x = 5.5,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 20,
    name = "transport-belt",
    position = {
      x = 6,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 21,
    name = "transport-belt",
    position = {
      x = 5,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 22,
    name = "splitter",
    position = {
      x = 7.5,
      y = -13
    }
  },
  {
    direction = 4,
    entity_number = 23,
    name = "transport-belt",
    position = {
      x = 8,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 24,
    name = "transport-belt",
    position = {
      x = 7,
      y = -14
    }
  },
  {
    direction = 4,
    entity_number = 25,
    name = "underground-belt",
    position = {
      x = -8,
      y = -11
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 26,
    name = "transport-belt",
    position = {
      x = -9,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 27,
    name = "splitter",
    position = {
      x = -7.5,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 28,
    name = "transport-belt",
    position = {
      x = -9,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 29,
    name = "transport-belt",
    position = {
      x = -6,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 30,
    name = "underground-belt",
    position = {
      x = -7,
      y = -11
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 31,
    name = "transport-belt",
    position = {
      x = -6,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 32,
    name = "underground-belt",
    position = {
      x = -4,
      y = -11
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 33,
    name = "transport-belt",
    position = {
      x = -5,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 34,
    name = "splitter",
    position = {
      x = -3.5,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 35,
    name = "transport-belt",
    position = {
      x = -5,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 36,
    name = "transport-belt",
    position = {
      x = -2,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 37,
    name = "underground-belt",
    position = {
      x = -3,
      y = -11
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 38,
    name = "transport-belt",
    position = {
      x = -2,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 39,
    name = "underground-belt",
    position = {
      x = 2,
      y = -11
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 40,
    name = "transport-belt",
    position = {
      x = 1,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 41,
    name = "splitter",
    position = {
      x = 2.5,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 42,
    name = "transport-belt",
    position = {
      x = 1,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 43,
    name = "transport-belt",
    position = {
      x = 4,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 44,
    name = "underground-belt",
    position = {
      x = 3,
      y = -11
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 45,
    name = "transport-belt",
    position = {
      x = 4,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 46,
    name = "underground-belt",
    position = {
      x = 6,
      y = -11
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 47,
    name = "transport-belt",
    position = {
      x = 5,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 48,
    name = "splitter",
    position = {
      x = 6.5,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 49,
    name = "transport-belt",
    position = {
      x = 5,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 50,
    name = "transport-belt",
    position = {
      x = 8,
      y = -11
    }
  },
  {
    direction = 4,
    entity_number = 51,
    name = "underground-belt",
    position = {
      x = 7,
      y = -11
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 52,
    name = "transport-belt",
    position = {
      x = 8,
      y = -12
    }
  },
  {
    direction = 4,
    entity_number = 53,
    name = "splitter",
    position = {
      x = -7.5,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 54,
    name = "transport-belt",
    position = {
      x = -8,
      y = -10
    }
  },
  {
    direction = 2,
    entity_number = 55,
    name = "transport-belt",
    position = {
      x = -9,
      y = -10
    }
  },
  {
    direction = 6,
    entity_number = 56,
    name = "transport-belt",
    position = {
      x = -6,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 57,
    name = "transport-belt",
    position = {
      x = -7,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 58,
    name = "splitter",
    position = {
      x = -3.5,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 59,
    name = "transport-belt",
    position = {
      x = -4,
      y = -10
    }
  },
  {
    direction = 2,
    entity_number = 60,
    name = "transport-belt",
    position = {
      x = -5,
      y = -10
    }
  },
  {
    direction = 6,
    entity_number = 61,
    name = "transport-belt",
    position = {
      x = -2,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 62,
    name = "transport-belt",
    position = {
      x = -3,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 63,
    name = "splitter",
    position = {
      x = 2.5,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 64,
    name = "transport-belt",
    position = {
      x = 2,
      y = -10
    }
  },
  {
    direction = 2,
    entity_number = 65,
    name = "transport-belt",
    position = {
      x = 1,
      y = -10
    }
  },
  {
    direction = 6,
    entity_number = 66,
    name = "transport-belt",
    position = {
      x = 4,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 67,
    name = "transport-belt",
    position = {
      x = 3,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 68,
    name = "splitter",
    position = {
      x = 6.5,
      y = -9
    }
  },
  {
    direction = 4,
    entity_number = 69,
    name = "transport-belt",
    position = {
      x = 6,
      y = -10
    }
  },
  {
    direction = 2,
    entity_number = 70,
    name = "transport-belt",
    position = {
      x = 5,
      y = -10
    }
  },
  {
    direction = 6,
    entity_number = 71,
    name = "transport-belt",
    position = {
      x = 8,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 72,
    name = "transport-belt",
    position = {
      x = 7,
      y = -10
    }
  },
  {
    direction = 4,
    entity_number = 73,
    name = "transport-belt",
    position = {
      x = -9,
      y = -7
    }
  },
  {
    direction = 6,
    entity_number = 74,
    name = "transport-belt",
    position = {
      x = -8,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 75,
    name = "transport-belt",
    position = {
      x = -9,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 76,
    name = "transport-belt",
    position = {
      x = -6,
      y = -7
    }
  },
  {
    direction = 4,
    entity_number = 77,
    name = "transport-belt",
    position = {
      x = -6,
      y = -8
    }
  },
  {
    direction = 2,
    entity_number = 78,
    name = "transport-belt",
    position = {
      x = -7,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 79,
    name = "underground-belt",
    position = {
      x = -5,
      y = -7
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 80,
    name = "transport-belt",
    position = {
      x = -4,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 81,
    name = "transport-belt",
    position = {
      x = -5,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 82,
    name = "underground-belt",
    position = {
      x = -4,
      y = -7
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 83,
    name = "transport-belt",
    position = {
      x = -2,
      y = -7
    }
  },
  {
    direction = 2,
    entity_number = 84,
    name = "transport-belt",
    position = {
      x = -2,
      y = -8
    }
  },
  {
    direction = 2,
    entity_number = 85,
    name = "transport-belt",
    position = {
      x = -3,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 86,
    name = "underground-belt",
    position = {
      x = -3,
      y = -7
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 87,
    name = "underground-belt",
    position = {
      x = 0,
      y = -7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 88,
    name = "transport-belt",
    position = {
      x = -1,
      y = -7
    }
  },
  {
    direction = 4,
    entity_number = 89,
    name = "transport-belt",
    position = {
      x = 0,
      y = -8
    }
  },
  {
    direction = 2,
    entity_number = 90,
    name = "transport-belt",
    position = {
      x = -1,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 91,
    name = "underground-belt",
    position = {
      x = 1,
      y = -7
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 92,
    name = "transport-belt",
    position = {
      x = 2,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 93,
    name = "transport-belt",
    position = {
      x = 1,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 94,
    name = "underground-belt",
    position = {
      x = 2,
      y = -7
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 95,
    name = "underground-belt",
    position = {
      x = 4,
      y = -7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 96,
    name = "transport-belt",
    position = {
      x = 4,
      y = -8
    }
  },
  {
    direction = 2,
    entity_number = 97,
    name = "transport-belt",
    position = {
      x = 3,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 98,
    name = "underground-belt",
    position = {
      x = 3,
      y = -7
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 99,
    name = "transport-belt",
    position = {
      x = 5,
      y = -7
    }
  },
  {
    direction = 6,
    entity_number = 100,
    name = "transport-belt",
    position = {
      x = 6,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 101,
    name = "transport-belt",
    position = {
      x = 5,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 102,
    name = "underground-belt",
    position = {
      x = 6,
      y = -7
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 103,
    name = "transport-belt",
    position = {
      x = 8,
      y = -7
    }
  },
  {
    direction = 4,
    entity_number = 104,
    name = "transport-belt",
    position = {
      x = 8,
      y = -8
    }
  },
  {
    direction = 2,
    entity_number = 105,
    name = "transport-belt",
    position = {
      x = 7,
      y = -8
    }
  },
  {
    direction = 4,
    entity_number = 106,
    name = "underground-belt",
    position = {
      x = 7,
      y = -7
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 107,
    name = "transport-belt",
    position = {
      x = -8,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 108,
    name = "transport-belt",
    position = {
      x = -9,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 109,
    name = "transport-belt",
    position = {
      x = -9,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 110,
    name = "underground-belt",
    position = {
      x = -8,
      y = -6
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 111,
    name = "underground-belt",
    position = {
      x = -6,
      y = -5
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 112,
    name = "transport-belt",
    position = {
      x = -7,
      y = -5
    }
  },
  {
    direction = 2,
    entity_number = 113,
    name = "transport-belt",
    position = {
      x = -6,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 114,
    name = "underground-belt",
    position = {
      x = -7,
      y = -6
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 115,
    name = "transport-belt",
    position = {
      x = -4,
      y = -5
    }
  },
  {
    direction = 2,
    entity_number = 116,
    name = "transport-belt",
    position = {
      x = -5,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 117,
    name = "underground-belt",
    position = {
      x = -4,
      y = -6
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 118,
    name = "transport-belt",
    position = {
      x = -5,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 119,
    name = "transport-belt",
    position = {
      x = -2,
      y = -5
    }
  },
  {
    direction = 2,
    entity_number = 120,
    name = "transport-belt",
    position = {
      x = -3,
      y = -5
    }
  },
  {
    entity_number = 121,
    name = "transport-belt",
    position = {
      x = -2,
      y = -6
    }
  },
  {
    direction = 2,
    entity_number = 122,
    name = "transport-belt",
    position = {
      x = -3,
      y = -6
    }
  },
  {
    direction = 2,
    entity_number = 123,
    name = "transport-belt",
    position = {
      x = 0,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 124,
    name = "underground-belt",
    position = {
      x = -1,
      y = -6
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 125,
    name = "underground-belt",
    position = {
      x = -1,
      y = -5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 126,
    name = "transport-belt",
    position = {
      x = 2,
      y = -5
    }
  },
  {
    direction = 2,
    entity_number = 127,
    name = "underground-belt",
    position = {
      x = 1,
      y = -5
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 128,
    name = "transport-belt",
    position = {
      x = 2,
      y = -6
    }
  },
  {
    direction = 6,
    entity_number = 129,
    name = "transport-belt",
    position = {
      x = 4,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 130,
    name = "transport-belt",
    position = {
      x = 3,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 131,
    name = "transport-belt",
    position = {
      x = 4,
      y = -6
    }
  },
  {
    direction = 4,
    entity_number = 132,
    name = "underground-belt",
    position = {
      x = 3,
      y = -6
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 133,
    name = "underground-belt",
    position = {
      x = 6,
      y = -6
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 134,
    name = "transport-belt",
    position = {
      x = 5,
      y = -6
    }
  },
  {
    direction = 2,
    entity_number = 135,
    name = "underground-belt",
    position = {
      x = 6,
      y = -5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 136,
    name = "transport-belt",
    position = {
      x = 8,
      y = -5
    }
  },
  {
    direction = 2,
    entity_number = 137,
    name = "transport-belt",
    position = {
      x = 7,
      y = -5
    }
  },
  {
    direction = 4,
    entity_number = 138,
    name = "underground-belt",
    position = {
      x = 8,
      y = -6
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 139,
    name = "underground-belt",
    position = {
      x = 7,
      y = -6
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 140,
    name = "transport-belt",
    position = {
      x = -8,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 141,
    name = "transport-belt",
    position = {
      x = -9,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 142,
    name = "transport-belt",
    position = {
      x = -8,
      y = -4
    }
  },
  {
    direction = 4,
    entity_number = 143,
    name = "transport-belt",
    position = {
      x = -9,
      y = -4
    }
  },
  {
    direction = 4,
    entity_number = 144,
    name = "transport-belt",
    position = {
      x = -6,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 145,
    name = "transport-belt",
    position = {
      x = -7,
      y = -3
    }
  },
  {
    direction = 6,
    entity_number = 146,
    name = "underground-belt",
    position = {
      x = -6,
      y = -4
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 147,
    name = "transport-belt",
    position = {
      x = -7,
      y = -4
    }
  },
  {
    direction = 6,
    entity_number = 148,
    name = "transport-belt",
    position = {
      x = -4,
      y = -3
    }
  },
  {
    direction = 6,
    entity_number = 149,
    name = "transport-belt",
    position = {
      x = -5,
      y = -3
    }
  },
  {
    direction = 6,
    entity_number = 150,
    name = "transport-belt",
    position = {
      x = -2,
      y = -3
    }
  },
  {
    direction = 6,
    entity_number = 151,
    name = "transport-belt",
    position = {
      x = -3,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 152,
    name = "underground-belt",
    position = {
      x = -2,
      y = -4
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 153,
    name = "underground-belt",
    position = {
      x = -1,
      y = -3
    },
    type = "output"
  },
  {
    direction = 6,
    entity_number = 154,
    name = "transport-belt",
    position = {
      x = 0,
      y = -4
    }
  },
  {
    direction = 6,
    entity_number = 155,
    name = "underground-belt",
    position = {
      x = -1,
      y = -4
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 156,
    name = "transport-belt",
    position = {
      x = 2,
      y = -4
    }
  },
  {
    direction = 6,
    entity_number = 157,
    name = "transport-belt",
    position = {
      x = 1,
      y = -4
    }
  },
  {
    direction = 4,
    entity_number = 158,
    name = "transport-belt",
    position = {
      x = 3,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 159,
    name = "transport-belt",
    position = {
      x = 3,
      y = -4
    }
  },
  {
    direction = 6,
    entity_number = 160,
    name = "underground-belt",
    position = {
      x = 4,
      y = -3
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 161,
    name = "transport-belt",
    position = {
      x = 6,
      y = -3
    }
  },
  {
    direction = 6,
    entity_number = 162,
    name = "transport-belt",
    position = {
      x = 5,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 163,
    name = "transport-belt",
    position = {
      x = 8,
      y = -3
    }
  },
  {
    direction = 6,
    entity_number = 164,
    name = "transport-belt",
    position = {
      x = 7,
      y = -3
    }
  },
  {
    direction = 4,
    entity_number = 165,
    name = "transport-belt",
    position = {
      x = 8,
      y = -4
    }
  },
  {
    direction = 4,
    entity_number = 166,
    name = "underground-belt",
    position = {
      x = 7,
      y = -4
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 167,
    name = "transport-belt",
    position = {
      x = -8,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 168,
    name = "transport-belt",
    position = {
      x = -9,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 169,
    name = "transport-belt",
    position = {
      x = -8,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 170,
    name = "transport-belt",
    position = {
      x = -9,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 171,
    name = "splitter",
    position = {
      x = -6.5,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 172,
    name = "transport-belt",
    position = {
      x = -6,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 173,
    name = "transport-belt",
    position = {
      x = -7,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 174,
    name = "underground-belt",
    position = {
      x = -5,
      y = -1
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 175,
    name = "underground-belt",
    position = {
      x = -4,
      y = -1
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 176,
    name = "underground-belt",
    position = {
      x = -5,
      y = -2
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 177,
    name = "transport-belt",
    position = {
      x = -3,
      y = -1
    }
  },
  {
    direction = 6,
    entity_number = 178,
    name = "underground-belt",
    position = {
      x = -2,
      y = -2
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 179,
    name = "transport-belt",
    position = {
      x = -3,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 180,
    name = "underground-belt",
    position = {
      x = -2,
      y = -1
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 181,
    name = "underground-belt",
    position = {
      x = 0,
      y = -1
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 182,
    name = "underground-belt",
    position = {
      x = -1,
      y = -1
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 183,
    name = "underground-belt",
    position = {
      x = -1,
      y = -2
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 184,
    name = "underground-belt",
    position = {
      x = 0,
      y = -2
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 185,
    name = "transport-belt",
    position = {
      x = 2,
      y = -1
    }
  },
  {
    direction = 2,
    entity_number = 186,
    name = "transport-belt",
    position = {
      x = 1,
      y = -1
    }
  },
  {
    direction = 6,
    entity_number = 187,
    name = "underground-belt",
    position = {
      x = 2,
      y = -2
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 188,
    name = "underground-belt",
    position = {
      x = 1,
      y = -2
    },
    type = "output"
  },
  {
    direction = 2,
    entity_number = 189,
    name = "transport-belt",
    position = {
      x = 4,
      y = -1
    }
  },
  {
    direction = 6,
    entity_number = 190,
    name = "transport-belt",
    position = {
      x = 3,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 191,
    name = "underground-belt",
    position = {
      x = 3,
      y = -1
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 192,
    name = "underground-belt",
    position = {
      x = 4,
      y = -2
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 193,
    name = "transport-belt",
    position = {
      x = 5,
      y = -1
    }
  },
  {
    direction = 4,
    entity_number = 194,
    name = "underground-belt",
    position = {
      x = 6,
      y = -1
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 195,
    name = "transport-belt",
    position = {
      x = 7,
      y = -1
    }
  },
  {
    direction = 6,
    entity_number = 196,
    name = "transport-belt",
    position = {
      x = 8,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 197,
    name = "transport-belt",
    position = {
      x = 7,
      y = -2
    }
  },
  {
    direction = 4,
    entity_number = 198,
    name = "underground-belt",
    position = {
      x = 8,
      y = -1
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 199,
    name = "transport-belt",
    position = {
      x = -8,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 200,
    name = "transport-belt",
    position = {
      x = -9,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 201,
    name = "transport-belt",
    position = {
      x = -8,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 202,
    name = "transport-belt",
    position = {
      x = -9,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 203,
    name = "underground-belt",
    position = {
      x = -6,
      y = 0
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 204,
    name = "underground-belt",
    position = {
      x = -7,
      y = 0
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 205,
    name = "transport-belt",
    position = {
      x = -4,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 206,
    name = "transport-belt",
    position = {
      x = -5,
      y = 1
    }
  },
  {
    direction = 6,
    entity_number = 207,
    name = "transport-belt",
    position = {
      x = -4,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 208,
    name = "transport-belt",
    position = {
      x = -5,
      y = 0
    }
  },
  {
    direction = 6,
    entity_number = 209,
    name = "transport-belt",
    position = {
      x = -3,
      y = 1
    }
  },
  {
    direction = 2,
    entity_number = 210,
    name = "transport-belt",
    position = {
      x = -2,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 211,
    name = "transport-belt",
    position = {
      x = -3,
      y = 0
    }
  },
  {
    direction = 2,
    entity_number = 212,
    name = "transport-belt",
    position = {
      x = 0,
      y = 0
    }
  },
  {
    direction = 2,
    entity_number = 213,
    name = "transport-belt",
    position = {
      x = -1,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 214,
    name = "transport-belt",
    position = {
      x = 2,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 215,
    name = "underground-belt",
    position = {
      x = 1,
      y = 1
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 216,
    name = "transport-belt",
    position = {
      x = 2,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 217,
    name = "transport-belt",
    position = {
      x = 1,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 218,
    name = "transport-belt",
    position = {
      x = 4,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 219,
    name = "transport-belt",
    position = {
      x = 3,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 220,
    name = "transport-belt",
    position = {
      x = 3,
      y = 0
    }
  },
  {
    direction = 6,
    entity_number = 221,
    name = "transport-belt",
    position = {
      x = 6,
      y = 1
    }
  },
  {
    direction = 6,
    entity_number = 222,
    name = "transport-belt",
    position = {
      x = 5,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 223,
    name = "transport-belt",
    position = {
      x = 6,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 224,
    name = "underground-belt",
    position = {
      x = 5,
      y = 0
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 225,
    name = "transport-belt",
    position = {
      x = 8,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 226,
    name = "transport-belt",
    position = {
      x = 7,
      y = 1
    }
  },
  {
    direction = 4,
    entity_number = 227,
    name = "transport-belt",
    position = {
      x = 8,
      y = 0
    }
  },
  {
    direction = 4,
    entity_number = 228,
    name = "transport-belt",
    position = {
      x = 7,
      y = 0
    }
  },
  {
    direction = 2,
    entity_number = 229,
    name = "transport-belt",
    position = {
      x = -8,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 230,
    name = "transport-belt",
    position = {
      x = -9,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 231,
    name = "transport-belt",
    position = {
      x = -8,
      y = 2
    }
  },
  {
    direction = 4,
    entity_number = 232,
    name = "transport-belt",
    position = {
      x = -9,
      y = 2
    }
  },
  {
    direction = 4,
    entity_number = 233,
    name = "transport-belt",
    position = {
      x = -6,
      y = 3
    }
  },
  {
    direction = 2,
    entity_number = 234,
    name = "underground-belt",
    position = {
      x = -7,
      y = 3
    },
    type = "input"
  },
  {
    direction = 6,
    entity_number = 235,
    name = "transport-belt",
    position = {
      x = -5,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 236,
    name = "underground-belt",
    position = {
      x = -4,
      y = 2
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 237,
    name = "transport-belt",
    position = {
      x = -5,
      y = 2
    }
  },
  {
    direction = 2,
    entity_number = 238,
    name = "underground-belt",
    position = {
      x = -4,
      y = 3
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 239,
    name = "transport-belt",
    position = {
      x = -2,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 240,
    name = "transport-belt",
    position = {
      x = -3,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 241,
    name = "transport-belt",
    position = {
      x = -2,
      y = 2
    }
  },
  {
    direction = 2,
    entity_number = 242,
    name = "transport-belt",
    position = {
      x = 0,
      y = 3
    }
  },
  {
    direction = 6,
    entity_number = 243,
    name = "underground-belt",
    position = {
      x = -1,
      y = 2
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 244,
    name = "underground-belt",
    position = {
      x = 0,
      y = 2
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 245,
    name = "underground-belt",
    position = {
      x = -1,
      y = 3
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 246,
    name = "transport-belt",
    position = {
      x = 2,
      y = 3
    }
  },
  {
    direction = 2,
    entity_number = 247,
    name = "transport-belt",
    position = {
      x = 1,
      y = 3
    }
  },
  {
    direction = 6,
    entity_number = 248,
    name = "transport-belt",
    position = {
      x = 2,
      y = 2
    }
  },
  {
    direction = 6,
    entity_number = 249,
    name = "underground-belt",
    position = {
      x = 1,
      y = 2
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 250,
    name = "underground-belt",
    position = {
      x = 4,
      y = 3
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 251,
    name = "transport-belt",
    position = {
      x = 3,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 252,
    name = "splitter",
    position = {
      x = 3.5,
      y = 2
    }
  },
  {
    direction = 4,
    entity_number = 253,
    name = "transport-belt",
    position = {
      x = 6,
      y = 3
    }
  },
  {
    direction = 2,
    entity_number = 254,
    name = "transport-belt",
    position = {
      x = 5,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 255,
    name = "underground-belt",
    position = {
      x = 5,
      y = 2
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 256,
    name = "transport-belt",
    position = {
      x = 8,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 257,
    name = "transport-belt",
    position = {
      x = 7,
      y = 3
    }
  },
  {
    direction = 4,
    entity_number = 258,
    name = "transport-belt",
    position = {
      x = 8,
      y = 2
    }
  },
  {
    direction = 4,
    entity_number = 259,
    name = "transport-belt",
    position = {
      x = 7,
      y = 2
    }
  },
  {
    direction = 4,
    entity_number = 260,
    name = "splitter",
    position = {
      x = -8.5,
      y = 5
    }
  },
  {
    direction = 4,
    entity_number = 261,
    name = "transport-belt",
    position = {
      x = -8,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 262,
    name = "transport-belt",
    position = {
      x = -9,
      y = 4
    }
  },
  {
    direction = 6,
    entity_number = 263,
    name = "transport-belt",
    position = {
      x = -6,
      y = 4
    }
  },
  {
    direction = 6,
    entity_number = 264,
    name = "transport-belt",
    position = {
      x = -7,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 265,
    name = "underground-belt",
    position = {
      x = -6,
      y = 5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 266,
    name = "underground-belt",
    position = {
      x = -7,
      y = 5
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 267,
    name = "splitter",
    position = {
      x = -4.5,
      y = 5
    }
  },
  {
    direction = 4,
    entity_number = 268,
    name = "underground-belt",
    position = {
      x = -4,
      y = 4
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 269,
    name = "underground-belt",
    position = {
      x = -5,
      y = 4
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 270,
    name = "splitter",
    position = {
      x = -2.5,
      y = 5
    }
  },
  {
    direction = 4,
    entity_number = 271,
    name = "transport-belt",
    position = {
      x = -2,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 272,
    name = "transport-belt",
    position = {
      x = -3,
      y = 4
    }
  },
  {
    direction = 2,
    entity_number = 273,
    name = "underground-belt",
    position = {
      x = 0,
      y = 4
    },
    type = "input"
  },
  {
    direction = 2,
    entity_number = 274,
    name = "transport-belt",
    position = {
      x = -1,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 275,
    name = "splitter",
    position = {
      x = 1.5,
      y = 5
    }
  },
  {
    direction = 4,
    entity_number = 276,
    name = "transport-belt",
    position = {
      x = 2,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 277,
    name = "underground-belt",
    position = {
      x = 1,
      y = 4
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 278,
    name = "transport-belt",
    position = {
      x = 3,
      y = 5
    }
  },
  {
    direction = 4,
    entity_number = 279,
    name = "transport-belt",
    position = {
      x = 3,
      y = 4
    }
  },
  {
    direction = 2,
    entity_number = 280,
    name = "underground-belt",
    position = {
      x = 4,
      y = 4
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 281,
    name = "splitter",
    position = {
      x = 5.5,
      y = 5
    }
  },
  {
    direction = 4,
    entity_number = 282,
    name = "transport-belt",
    position = {
      x = 6,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 283,
    name = "transport-belt",
    position = {
      x = 5,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 284,
    name = "splitter",
    position = {
      x = 7.5,
      y = 5
    }
  },
  {
    direction = 4,
    entity_number = 285,
    name = "transport-belt",
    position = {
      x = 8,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 286,
    name = "transport-belt",
    position = {
      x = 7,
      y = 4
    }
  },
  {
    direction = 4,
    entity_number = 287,
    name = "underground-belt",
    position = {
      x = -8,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 288,
    name = "transport-belt",
    position = {
      x = -9,
      y = 7
    }
  },
  {
    direction = 4,
    entity_number = 289,
    name = "splitter",
    position = {
      x = -7.5,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 290,
    name = "transport-belt",
    position = {
      x = -9,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 291,
    name = "transport-belt",
    position = {
      x = -6,
      y = 7
    }
  },
  {
    direction = 4,
    entity_number = 292,
    name = "underground-belt",
    position = {
      x = -7,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 293,
    name = "transport-belt",
    position = {
      x = -6,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 294,
    name = "underground-belt",
    position = {
      x = -4,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 295,
    name = "transport-belt",
    position = {
      x = -5,
      y = 7
    }
  },
  {
    direction = 4,
    entity_number = 296,
    name = "splitter",
    position = {
      x = -3.5,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 297,
    name = "transport-belt",
    position = {
      x = -5,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 298,
    name = "transport-belt",
    position = {
      x = -2,
      y = 7
    }
  },
  {
    direction = 4,
    entity_number = 299,
    name = "underground-belt",
    position = {
      x = -3,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 300,
    name = "transport-belt",
    position = {
      x = -2,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 301,
    name = "underground-belt",
    position = {
      x = 2,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 302,
    name = "transport-belt",
    position = {
      x = 1,
      y = 7
    }
  },
  {
    direction = 4,
    entity_number = 303,
    name = "splitter",
    position = {
      x = 2.5,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 304,
    name = "transport-belt",
    position = {
      x = 1,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 305,
    name = "underground-belt",
    position = {
      x = 3,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 306,
    name = "underground-belt",
    position = {
      x = 4,
      y = 7
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 307,
    name = "underground-belt",
    position = {
      x = 6,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 308,
    name = "transport-belt",
    position = {
      x = 5,
      y = 7
    }
  },
  {
    direction = 4,
    entity_number = 309,
    name = "splitter",
    position = {
      x = 6.5,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 310,
    name = "transport-belt",
    position = {
      x = 5,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 311,
    name = "transport-belt",
    position = {
      x = 8,
      y = 7
    }
  },
  {
    direction = 4,
    entity_number = 312,
    name = "underground-belt",
    position = {
      x = 7,
      y = 7
    },
    type = "input"
  },
  {
    direction = 4,
    entity_number = 313,
    name = "transport-belt",
    position = {
      x = 8,
      y = 6
    }
  },
  {
    direction = 4,
    entity_number = 314,
    name = "splitter",
    position = {
      x = -7.5,
      y = 9
    }
  },
  {
    direction = 4,
    entity_number = 315,
    name = "transport-belt",
    position = {
      x = -8,
      y = 8
    }
  },
  {
    direction = 2,
    entity_number = 316,
    name = "transport-belt",
    position = {
      x = -9,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 317,
    name = "transport-belt",
    position = {
      x = -6,
      y = 8
    }
  },
  {
    direction = 4,
    entity_number = 318,
    name = "transport-belt",
    position = {
      x = -7,
      y = 8
    }
  },
  {
    direction = 4,
    entity_number = 319,
    name = "splitter",
    position = {
      x = -3.5,
      y = 9
    }
  },
  {
    direction = 4,
    entity_number = 320,
    name = "transport-belt",
    position = {
      x = -4,
      y = 8
    }
  },
  {
    direction = 2,
    entity_number = 321,
    name = "transport-belt",
    position = {
      x = -5,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 322,
    name = "transport-belt",
    position = {
      x = -2,
      y = 8
    }
  },
  {
    direction = 4,
    entity_number = 323,
    name = "transport-belt",
    position = {
      x = -3,
      y = 8
    }
  },
  {
    direction = 4,
    entity_number = 324,
    name = "splitter",
    position = {
      x = 2.5,
      y = 9
    }
  },
  {
    direction = 4,
    entity_number = 325,
    name = "transport-belt",
    position = {
      x = 2,
      y = 8
    }
  },
  {
    direction = 2,
    entity_number = 326,
    name = "transport-belt",
    position = {
      x = 1,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 327,
    name = "transport-belt",
    position = {
      x = 4,
      y = 8
    }
  },
  {
    direction = 4,
    entity_number = 328,
    name = "transport-belt",
    position = {
      x = 3,
      y = 8
    }
  },
  {
    direction = 4,
    entity_number = 329,
    name = "splitter",
    position = {
      x = 6.5,
      y = 9
    }
  },
  {
    direction = 4,
    entity_number = 330,
    name = "transport-belt",
    position = {
      x = 6,
      y = 8
    }
  },
  {
    direction = 2,
    entity_number = 331,
    name = "transport-belt",
    position = {
      x = 5,
      y = 8
    }
  },
  {
    direction = 6,
    entity_number = 332,
    name = "transport-belt",
    position = {
      x = 8,
      y = 8
    }
  },
  {
    direction = 4,
    entity_number = 333,
    name = "transport-belt",
    position = {
      x = 7,
      y = 8
    }
  },
  {
    direction = 4,
    entity_number = 334,
    name = "transport-belt",
    position = {
      x = -9,
      y = 11
    }
  },
  {
    direction = 6,
    entity_number = 335,
    name = "transport-belt",
    position = {
      x = -8,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 336,
    name = "transport-belt",
    position = {
      x = -9,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 337,
    name = "underground-belt",
    position = {
      x = -8,
      y = 11
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 338,
    name = "transport-belt",
    position = {
      x = -6,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 339,
    name = "transport-belt",
    position = {
      x = -6,
      y = 10
    }
  },
  {
    direction = 2,
    entity_number = 340,
    name = "transport-belt",
    position = {
      x = -7,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 341,
    name = "underground-belt",
    position = {
      x = -7,
      y = 11
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 342,
    name = "transport-belt",
    position = {
      x = -5,
      y = 11
    }
  },
  {
    direction = 6,
    entity_number = 343,
    name = "transport-belt",
    position = {
      x = -4,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 344,
    name = "transport-belt",
    position = {
      x = -5,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 345,
    name = "underground-belt",
    position = {
      x = -4,
      y = 11
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 346,
    name = "transport-belt",
    position = {
      x = -2,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 347,
    name = "transport-belt",
    position = {
      x = -2,
      y = 10
    }
  },
  {
    direction = 2,
    entity_number = 348,
    name = "transport-belt",
    position = {
      x = -3,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 349,
    name = "underground-belt",
    position = {
      x = -3,
      y = 11
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 350,
    name = "transport-belt",
    position = {
      x = 1,
      y = 11
    }
  },
  {
    direction = 6,
    entity_number = 351,
    name = "transport-belt",
    position = {
      x = 2,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 352,
    name = "transport-belt",
    position = {
      x = 1,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 353,
    name = "underground-belt",
    position = {
      x = 2,
      y = 11
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 354,
    name = "transport-belt",
    position = {
      x = 4,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 355,
    name = "transport-belt",
    position = {
      x = 4,
      y = 10
    }
  },
  {
    direction = 2,
    entity_number = 356,
    name = "transport-belt",
    position = {
      x = 3,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 357,
    name = "underground-belt",
    position = {
      x = 3,
      y = 11
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 358,
    name = "transport-belt",
    position = {
      x = 5,
      y = 11
    }
  },
  {
    direction = 6,
    entity_number = 359,
    name = "transport-belt",
    position = {
      x = 6,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 360,
    name = "transport-belt",
    position = {
      x = 5,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 361,
    name = "underground-belt",
    position = {
      x = 6,
      y = 11
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 362,
    name = "transport-belt",
    position = {
      x = 8,
      y = 11
    }
  },
  {
    direction = 4,
    entity_number = 363,
    name = "transport-belt",
    position = {
      x = 8,
      y = 10
    }
  },
  {
    direction = 2,
    entity_number = 364,
    name = "transport-belt",
    position = {
      x = 7,
      y = 10
    }
  },
  {
    direction = 4,
    entity_number = 365,
    name = "underground-belt",
    position = {
      x = 7,
      y = 11
    },
    type = "output"
  },
  {
    direction = 4,
    entity_number = 366,
    name = "transport-belt",
    position = {
      x = -8,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 367,
    name = "transport-belt",
    position = {
      x = -9,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 368,
    name = "splitter",
    position = {
      x = -8.5,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 369,
    name = "transport-belt",
    position = {
      x = -6,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 370,
    name = "transport-belt",
    position = {
      x = -7,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 371,
    name = "splitter",
    position = {
      x = -6.5,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 372,
    name = "transport-belt",
    position = {
      x = -4,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 373,
    name = "transport-belt",
    position = {
      x = -5,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 374,
    name = "splitter",
    position = {
      x = -4.5,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 375,
    name = "transport-belt",
    position = {
      x = -2,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 376,
    name = "transport-belt",
    position = {
      x = -3,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 377,
    name = "splitter",
    position = {
      x = -2.5,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 378,
    name = "transport-belt",
    position = {
      x = 2,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 379,
    name = "transport-belt",
    position = {
      x = 1,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 380,
    name = "splitter",
    position = {
      x = 1.5,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 381,
    name = "transport-belt",
    position = {
      x = 4,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 382,
    name = "transport-belt",
    position = {
      x = 3,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 383,
    name = "splitter",
    position = {
      x = 3.5,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 384,
    name = "transport-belt",
    position = {
      x = 6,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 385,
    name = "transport-belt",
    position = {
      x = 5,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 386,
    name = "splitter",
    position = {
      x = 5.5,
      y = 12
    }
  },
  {
    direction = 4,
    entity_number = 387,
    name = "transport-belt",
    position = {
      x = 8,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 388,
    name = "transport-belt",
    position = {
      x = 7,
      y = 13
    }
  },
  {
    direction = 4,
    entity_number = 389,
    name = "splitter",
    position = {
      x = 7.5,
      y = 12
    }
  }
}