--data.lua

require("prototypes.gui_signal_display_entity")
require("prototypes.technology")
require("prototypes.recipe")
require("prototypes.ui_style")
