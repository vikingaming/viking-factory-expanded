data.raw["gui-style"].default["gui_signal_display_scroll"] =
{
    type = "scroll_pane_style",
    maximal_width = 300
}

data.raw["gui-style"].default["gui_signal_display_list"] =
{
    type = "scroll_pane_style",
    minimal_width = 300,
    minimal_height = 400,
    maximal_width = 800,
    maximal_height = 800
}
