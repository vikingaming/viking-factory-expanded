data:extend({
{
    type = "recipe",
    name = "gui-signal-display",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"radar", 4},
      {"green-wire", 40},
      {"red-wire", 40},
      {"small-lamp", 10}
    },
    result = "gui-signal-display"
  }
})
