data.raw.item["constant-combinator"].group = "useful-combinators"
data.raw.item["constant-combinator"].subgroup = "main"
data.raw.item["constant-combinator"].order = "a"