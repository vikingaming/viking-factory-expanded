data.raw["gui-style"]["default"]["uc_text"] =
{
  type = "textfield_style",
  maximal_width = 64
}