# PlannerCore v0.1.1

Core mod for the planner series of mods ([Outpost Planner](https://github.com/Ben-Ramchandani/OutpostPlanner)).

This mod contains most of the code, allowing the mods to call each other without all of them being installed.

[Link to Factorio mod website](https://mods.factorio.com/mods/bob809/PlannerCore)

Please submit bug reports to the issues page of the mod you're using when the crash occurs, to help avoid duplicates.

## Changelog

0.1.1

* Fixed bug with other entities only being placed when miners are.

0.1.0

* First public version (Factorio version 0.16.1).
