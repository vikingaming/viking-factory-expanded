
-- Returns the maximize button if it is displayed, nil otherwise
function lsm.get_maximize_button(player)
    local buttons = mod_gui.get_button_flow(player);

    if buttons.lsm_maximize_button then
        return  buttons.lsm_maximize_button
    else
        return nil
    end
end

function lsm.get_main_frame(player)
    return mod_gui.get_frame_flow(player).lsm_main_frame;
end

function lsm.GetPresetNameFromElementName(name, pattern)
    local _, start = string.find(name, pattern)
    return string.sub(name, start+1)
end