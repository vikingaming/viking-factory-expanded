if not lsmTrash then lsmTrash = {} end

function lsmTrash.TrashPreset(player, preset)
    if not player.valid then return end
    if not player.character.valid then return end

    local filters = player.character.auto_trash_filters
    for index, slot in pairs(preset.slots) do
        if not lsmRequest.IsItemRequested(slot.name) then
            filters[slot.name] = 0
        end
    end
    player.character.auto_trash_filters = filters
end

function lsmTrash.ClearPreset(player, preset)
    if not player.valid then return end
    if not player.character.valid then return end

    local filters = player.character.auto_trash_filters
    for index, slot in pairs(preset.slots) do
        if (filters[slot.name]) then
            filters[slot.name] = nil
        end
    end
    player.character.auto_trash_filters = filters
end
