require "lsm"

-- when creating a new game, initialize data structure
script.on_init(lsm.mod_init)

-- When a player is joining, create the UI for them
script.on_event(defines.events.on_player_created, function(event)
    local player = game.players[event.player_index]
    lsmUi.CreateMinimizedButton(player)
end)

-- if the version of the mod or any other version changed
script.on_configuration_changed(lsm.mod_init)

script.on_event(defines.events.on_gui_click, function(event)
    lsm.on_gui_click(event)
end)
