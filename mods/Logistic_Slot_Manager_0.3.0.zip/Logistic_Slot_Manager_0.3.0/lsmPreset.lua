if not global.lsm then global.lsm = {} end
if not global.lsm.presets then global.lsm.presets = {} end
if not lsmPreset then lsmPreset = {} end

function lsmPreset.Delete(name)
    for i, preset in pairs(global.lsm.presets) do
        if (preset.name == name) then
            global.lsm.presets[i] = nil
            return
        end
    end
end

function lsmPreset.Create(name)
    local preset = lsmPreset.Get(name)
    if preset then return preset end

    preset = { name = name, state = "idle", slots = {}}

    global.lsm.presets[#global.lsm.presets+1] = preset

    return preset
end

function lsmPreset.Get(name)
    for i, preset in pairs(global.lsm.presets) do
        if (preset.name == name) then
            return preset
        end
    end
end

function lsmPreset.ClearSlots(name)
    local preset = lsmPreset.Get(name)
    if not preset then return end

    preset.slots = {}
end

function lsmPreset.SetSlotCount(name, item, count)
    local preset = lsmPreset.Get(name)
    if not preset then return end

    for i, slot in pairs(preset.slots) do
        if (slot.name == item) then
            slot.count = count
            return
        end
    end
    preset.slots[#preset.slots + 1] = {name=item, count = count}
end
