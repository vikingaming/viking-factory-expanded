if not lsmUi then lsmUi = {} end

function lsmUi.CreateMinimizedButton(player)
    local flow = mod_gui.get_button_flow(player)

    if flow.lsm_maximize_button then return end

    mod_gui.get_button_flow(player).add({
        type = "sprite-button",
        name = "lsm_maximize_button",
        sprite= "item/logistic-robot",
        tooltip = {"lsm.window_title"},
        style = mod_gui.button_style
    })
end

function lsmUi.CreateMaximizedFrame(player)

    local frame = mod_gui.get_frame_flow(player).add{ type = "frame", name = "lsm_main_frame", caption = {"lsm.window_title"}, direction = "vertical" }

    local pt = frame.add{ type = "table", name = "lsm_main_preset_table", column_count="3" }
    pt.style.minimal_width = 150
    pt.style.column_alignments[1] = "middle-right"
    pt.style.column_alignments[2] = "center"
    pt.style.column_alignments[3] = "middle-left"

            
    local flow = frame.add{ type = "flow", name = "lsm_main_button_flow", direction = "horizontal" }
    flow.add{ type = "button", name = "lsm_setup_add_preset_button", caption="+", tooltip = {"lsm.button_add_preset"} }
    flow.add{ type = "button", name = "lsm_setup_button", caption={"lsm.button_setup"} }
    flow.add{ type = "button", name = "lsm_minimize_button", caption = "_", tooltip={"lsm.button_minimize"} }
end

function lsmUi.UpdateMainPresetStates(player, presets)
    local table = lsm.get_main_frame(player).lsm_main_preset_table
    if not table then 
        log("Could not find table to update")
        return 
    end

    for i, element in pairs(table.children) do
        element.destroy()
    end

    for i, preset in pairs(presets) do
        local trashButton = table.add{ type="button", name="lsm_main_toggle_trash_button_" .. preset.name, caption="-", tooltip={"lsm.tooltip_trash"}, style="small_slot_button"}
        local presetLabel = table.add{ type="label", name="lsm_main_preset_label_" .. preset.name, caption=preset.name, style="bold_label"}
        local reqButton = table.add{ type="button", name="lsm_main_toggle_request_button_" .. preset.name, caption="+", tooltip={"lsm.tooltip_request"}, style="small_slot_button"}
        
        if (preset.state == "idle") then
            presetLabel.tooltip = ""
            presetLabel.style = "bold_label"
        elseif (preset.state == "request") then
            presetLabel.tooltip = {"lsm.tooltip_request"}
            presetLabel.style = "bold_green_label"
        elseif (preset.state == "trash") then
            presetLabel.tooltip = {"lsm.tooltip_trash"}
            presetLabel.style = "bold_red_label"
        end
    end
end

function lsmUi.CreateSetupFrame(player)
    if (player.gui.center.lsm_setup_frame) then return end

    local frame = player.gui.center.add{ type = "frame", name = "lsm_setup_frame", caption = {"lsm.window_title"}, direction = "vertical" }
    
    local pt = frame.add{ type = "table", name = "lsm_preset_table", column_count="3" }
    pt.add{ type = "label", name = "lsm_title_name", caption = {"lsm.label_preset_name"} }
    pt.add{ type = "label", name = "lsm_title_slots", caption = {"lsm.label_preset_slots"} }
    pt.add{ type = "label" }
            
    local flow = frame.add{ type = "flow", name = "lsm_main_button_flow", direction = "horizontal" }
    flow.add{ type = "button", name = "lsm_setup_add_preset_button", caption = {"lsm.button_add_preset"} }
    flow.add{ type = "button", name = "lsm_setup_close_button", caption = {"lsm.button_close"} }
end

function lsmUi.GetSetupFrame(player)
    return player.gui.center.lsm_setup_frame
end

function lsmUi.DestroySetupFrame(player)
    if not (player.gui.center.lsm_setup_frame) then return end
    
    player.gui.center.lsm_setup_frame.destroy()
end

function lsmUi.AddPresetToSetup(table, preset)
	table.add{ type= "label", caption = preset.name, single_line=true }
	
	local flow = table.add({
		type="flow",
		name="lsm_preset_".. preset.name .."_slots",
		direction="horizontal"
	})
	
	for i, slot in pairs(preset.slots) do
        local button = flow.add{ type = "sprite", sprite = "item/" .. slot.name}
		button.style.minimal_width = 32
		button.style.minimal_height = 32

        local countlabel = button.add{ type="label", caption= slot.count, single_line=false }
        countlabel.style.top_padding = 10
        
    end
    
    local button = table.add{ type = "button", name ="lsm_preset_delete_" .. preset.name, caption="  -  " }
    button.style.font_color = {r=1}
	
end

function lsmUi.CreateAddPresetFrame(player, slots)
    if player.gui.center.lsm_new_preset_frame then return end

    local gui = player.gui.center

    local frame = gui.add{ type = "frame", name = "lsm_new_preset_frame", caption = {"lsm.new_preset_title"}, direction = "vertical" }
    local table = frame.add{ type = "table", name = "lsm_new_preset_table", column_count = 2 }

    table.add{ type="label", caption={"lsm.new_preset_name"} }

    local textbox = table.add{ type="text-box", name="lsm_new_preset_textbox"}
    textbox.style.minimal_width = 200
    textbox.style.minimal_height = 16

    table.add{ type = "label"}
    local flow = table.add { type="flow", direction="horizontal"}
	for i, slot in pairs(slots) do
        local button = flow.add{ type = "sprite", sprite = "item/" .. slot.name }
		button.style.minimal_width = 32
		button.style.minimal_height = 32

        local countlabel = button.add{ type="label", caption= slot.count, single_line=false }
        countlabel.style.top_padding = 10        
    end

    local flow = frame.add({ type = "flow", name = "lsm_new_preset_button_flow", direction = "horizontal" })
    flow.add({ type = "button", name = "lsm_new_preset_save_button", caption = {"lsm.button_save"} })
    flow.add({ type = "button", name = "lsm_new_preset_cancel_button", caption = {"lsm.button_cancel"} })

end

function lsmUi.DestroyAddPresetFrame(player)
    if not (player.gui.center.lsm_new_preset_frame) then return end

    player.gui.center.lsm_new_preset_frame.destroy()
end

function lsmUi.CreateDeletePresetFrame(presetName, player)
    if player.gui.center.lsm_delete_preset_frame then return end

    local gui = player.gui.center
    local frame = gui.add{ type="frame", name="lsm_delete_preset_frame", caption={"lsm.delete_preset_title"}, direction="vertical"}
    frame.add{type="label", caption={"lsm.delete_preset_text"}}
    local buttonFlow = frame.add{type="flow", direction="horizontal"}
    buttonFlow.add{ type="button", name="lsm_delete_preset_yes_button_" .. presetName, caption={"lsm.button_yes"}}
    buttonFlow.add{ type="button", name="lsm_delete_preset_no_button", caption={"lsm.button_no"}}
end

function lsmUi.DestroyDeletePresetFrame(player)
    if not (player.gui.center.lsm_delete_preset_frame) then return end

    player.gui.center.lsm_delete_preset_frame.destroy()
end
