if not lsm then lsm = {} end

require "mod-gui"
require "helper"
require "lsmRequest"
require "lsmTrash"
require "lsmUi"
require "lsmPreset"

function lsm.mod_init()
    if not global.lsm then
        global.lsm = { presets = {}}
    end

    for _, player in pairs(game.players) do
        lsmUi.CreateMinimizedButton(player)
    end
end

function lsm.Minimize(player)
    lsm.get_main_frame(player).destroy()
    log("Creating minimized button")
    lsmUi.CreateMinimizedButton(player)
end

function lsm.Maximize(player)
    local max_button = lsm.get_maximize_button(player)
    if max_button then
        max_button.destroy()
    end

    lsmUi.CreateMaximizedFrame(player)
end

function lsm.ToggleRequestPreset(player, name)
    local preset = lsmPreset.Get(name)

    if (preset.state == "request") then
        preset.state = "idle"
        lsmRequest.DeactivatePreset(player, preset)
        lsmTrash.ClearPreset(player, preset)
    else
        preset.state = "request"
        lsmRequest.ActivatePreset(player, preset)
        lsmTrash.ClearPreset(player, preset)
    end
    lsmUi.UpdateMainPresetStates(player, global.lsm.presets)
end

function lsm.ToggleTrashPreset(player, name)
    local preset = lsmPreset.Get(name)

    if (preset.state == "trash") then
        preset.state = "idle"
        lsmRequest.DeactivatePreset(player, preset)
        lsmTrash.ClearPreset(player, preset)
    else
        preset.state = "trash"
        lsmRequest.DeactivatePreset(player, preset)
        lsmTrash.TrashPreset(player, preset)
    end
    lsmUi.UpdateMainPresetStates(player, global.lsm.presets)
end

function lsm.RefreshSetupTable(player)
    -- Stop if table doesnt exist
    local setup_frame = lsmUi.GetSetupFrame(player)
    if not setup_frame then
        return
    end

    -- Clear table
    local table = setup_frame.lsm_preset_table
    for i, element in pairs(table.children) do
        if i > 3 then
            element.destroy()
        end
    end    

    for i, preset in pairs(global.lsm.presets) do
        lsmUi.AddPresetToSetup(table, preset)
    end
end

function lsm.CreateNewPreset(player, frame)
    local name = frame.lsm_new_preset_table.children[2].text

    local preset = lsmPreset.Create(name)
    preset.state = "request"

    local slots = lsmRequest.GetCharacterLogisticSlots(player)
    for index = 1, #slots, 1 do
        lsmPreset.SetSlotCount(name, slots[index].name, slots[index].count)
    end
end

function lsm.on_gui_click(event)
    local player = game.players[event.player_index]
	local presetframe = lsm.get_main_frame(player)
    local element = event.element

    if (element.name == "lsm_maximize_button") then
        lsm.Maximize(player)
        lsmUi.UpdateMainPresetStates(player, global.lsm.presets)
    elseif (element.name == "lsm_minimize_button") then
        lsm.Minimize(player)
    elseif (element.name == "lsm_setup_button") then
        lsmUi.CreateSetupFrame(player)
        lsm.RefreshSetupTable(player)
    elseif (element.name == "lsm_setup_close_button") then
        lsmUi.DestroySetupFrame(player)
    elseif (element.name == "lsm_setup_add_preset_button") then
        lsmUi.DestroySetupFrame(player)
        lsmUi.CreateAddPresetFrame(player, lsmRequest.GetCharacterLogisticSlots(player))
    elseif (element.name == "lsm_new_preset_save_button") then
        lsm.CreateNewPreset(player, element.parent.parent)
        lsmUi.UpdateMainPresetStates(player, global.lsm.presets)
        lsmUi.DestroyAddPresetFrame(player)
    elseif (element.name == "lsm_new_preset_cancel_button") then
        lsmUi.DestroyAddPresetFrame(player)
    elseif (element.name == "lsm_delete_preset_no_button") then
        lsmUi.DestroyDeletePresetFrame(player)
    elseif (string.find(element.name, "lsm_main_toggle_trash_button_")) then
        lsm.ToggleTrashPreset(player, lsm.GetPresetNameFromElementName(element.name, "lsm_main_toggle_trash_button_"))
    elseif (string.find(element.name, "lsm_main_toggle_request_button_")) then
        lsm.ToggleRequestPreset(player, lsm.GetPresetNameFromElementName(element.name, "lsm_main_toggle_request_button_"))
    elseif (string.find(element.name, "lsm_preset_delete_")) then
        local preset = lsm.GetPresetNameFromElementName(element.name, "lsm_preset_delete_")
        lsmUi.DestroySetupFrame(player)
        lsmUi.CreateDeletePresetFrame(preset, player)
    elseif (string.find(element.name, "lsm_delete_preset_yes_button_")) then
        local presetName = lsm.GetPresetNameFromElementName(element.name, "lsm_delete_preset_yes_button_")
        log("Deleting preset " .. presetName)
        log(serpent.block(global.lsm.presets))
        lsmPreset.Delete(presetName)
        lsmUi.DestroyDeletePresetFrame(player)
        lsmUi.UpdateMainPresetStates(player, global.lsm.presets)
        lsmUi.CreateSetupFrame(player)
        lsm.RefreshSetupTable(player)
    else
        log("Unknown element name:" .. element.name)
    end
end