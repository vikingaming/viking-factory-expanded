if not lsmRequest then lsmRequest = {} end

function lsmRequest.ActivatePreset(player, preset)
    if not player.valid then return end
    if not player.character.valid then return end

    for index, slot in pairs(preset.slots) do
        lsmRequest.Request(player, slot)
    end

    --game.raise_event(defines.events.on_player_main_inventory_changed)
end

function lsmRequest.DeactivatePreset(player, preset)
    if not player.valid then return end
    if not player.character.valid then return end

    for index, slot in pairs(preset.slots) do
        if not lsmRequest.IsItemRequested(slot.name) then
            lsmRequest.Clear(player, slot.name)
        end
    end
end

function lsmRequest.Request(player, item)
    if not player.valid then return end
    if not player.character.valid then return end

    local index = lsmRequest.GetRequestSlotIndexOfItem(player, item.name)
    if (index) then
        local slot = player.character.get_request_slot(index)
        if (slot.count < item.count) then
            slot.count = item.count
            player.character.set_request_slot(slot, index)
        end
        return
    end

    local index = lsmRequest.GetFirstAvailableRequestSlotIndex(player)
    if (index and item.count > 0) then
        player.character.set_request_slot(item, index)
    end
end

function lsmRequest.IsItemRequested(item)
    for i, preset in pairs(global.lsm.presets) do
        if (preset.state == "request") then
            for s, slot in pairs(preset.slots) do
                if (slot.name == item and slot.count  > 0) then
                    return true
                end
            end
        end
    end

    return false
end

function lsmRequest.Clear(player, itemName)
    if not player.valid then return end
    if not player.character.valid then return end

    local index = lsmRequest.GetRequestSlotIndexOfItem(player, itemName)
    if (index) then
        player.character.clear_request_slot(index)
    end
end

function lsmRequest.GetCharacterLogisticSlots(player)
	if not player.valid then return end
	if not player.character then return end
	
	local slots = {}
	local character = player.character
		
	for slot_index = 1, character.request_slot_count, 1 do
		local slot = character.get_request_slot(slot_index)
		
		if (slot and slot.count > 0) then
			slots[#slots+1] = slot
		end
	end

	return slots;
end

-- Internal use

function lsmRequest.GetRequestSlotIndexOfItem(player, itemName)
    if not player.valid then return nil end
    if not player.character.valid then return nil end

    for index = 1, player.character.request_slot_count, 1 do
        local slot = player.character.get_request_slot(index)
        if slot and slot.name == itemName then
            return index
        end
    end
end

function lsmRequest.GetFirstAvailableRequestSlotIndex(player)
    if not player.valid then return nil end
    if not player.character.valid then return nil end

    for index = 1, player.character.request_slot_count, 1 do
        local slot = player.character.get_request_slot(index)
        if not slot then return index end
    end
end