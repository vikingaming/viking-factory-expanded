# factorio-shuttle

A remake of the classic Shuttle Train mod by Simwir.

https://github.com/simwir/Shuttle-Train
