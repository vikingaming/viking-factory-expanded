return {
  ["advanced-combinator"] = 24
}
