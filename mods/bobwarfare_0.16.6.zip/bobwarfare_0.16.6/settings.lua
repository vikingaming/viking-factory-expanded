data:extend(
{
  {
    type = "bool-setting",
    name = "bobmods-warfare-robotupdate",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },
  {
    type = "bool-setting",
    name = "bobmods-warfare-drainlesslaserturrets",
    setting_type = "startup",
    default_value = false,
    per_user = false,
  },
}
)


