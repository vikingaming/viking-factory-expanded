data:extend(
{
  {
    type = "damage-type",
    name = "bob-pierce"
  },
}
)
