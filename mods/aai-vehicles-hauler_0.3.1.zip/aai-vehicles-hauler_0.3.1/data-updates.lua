if aai_industry then
  data.raw.recipe["vehicle-hauler"].normal.ingredients = {
        {type="item", name="iron-plate", amount=20},
        {type="item", name="motor", amount=6},
        {type="item", name="iron-chest", amount=5},
  }
  data.raw.recipe["vehicle-hauler"].expensive.ingredients = {
        {type="item", name="iron-plate", amount=20},
        {type="item", name="motor", amount=6},
        {type="item", name="iron-chest", amount=5},
  }
end
