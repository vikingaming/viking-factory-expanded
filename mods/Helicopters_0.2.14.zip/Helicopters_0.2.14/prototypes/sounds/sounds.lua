data:extend({
	{
		type = "sound",
		name = "heli-fuel-warning",
		filename = "__Helicopters__/sound/fuel_warning.ogg",
		volume = 0.5,
	},
})