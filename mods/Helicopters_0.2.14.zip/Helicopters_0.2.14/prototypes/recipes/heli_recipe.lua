data:extend({
	{
		type = "recipe",
		name = "heli-recipe",
		enabled = false,
		ingredients = {
			{"engine-unit", 150},
			{"steel-plate", 150},
			{"iron-gear-wheel", 250},
			{"processing-unit", 250},
			{"gun-turret", 10},
			{"rocket-launcher", 10},
		},
		result = "heli-item",
	}
})