# factorio-radar
Provides a control unit you can place next to radars that outputs the number of enemy and friendly units found in the radars permanent coverage area.
