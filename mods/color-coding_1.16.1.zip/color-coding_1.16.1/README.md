# factorio-color-coding

This is the continuation of a mod that d3phoenix put together by request for FireBlade212 on Twitch, because I want my colors!

It adds sets of color-coded indicator lamps, and concrete types to the game, which can be researched after their base technologies are unlocked.

The primary purpose of the mod is to help organize and color code your factories, though it could also be used decoratively, and the colored lamps may have interesting uses with the circuit network.

The included colors are red, orange, yellow, green, cyan, blue, purple, magenta, white, and black. There is also a fire hazard marking concrete.
