
data:extend(
{
  {
    type = "ammo-category",
    name = "Bio_Turret_Ammo",
    order = "1"
  },
}
)
