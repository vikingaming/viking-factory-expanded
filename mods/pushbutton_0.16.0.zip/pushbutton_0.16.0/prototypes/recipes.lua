data:extend{
  {
    type = "recipe",
    name = "pushbutton",
    enabled = "true",
    ingredients =
    {
      {"constant-combinator", 1},
      {"electronic-circuit", 1},
      {"advanced-circuit", 1},
    },
    result="pushbutton",
  },
}
