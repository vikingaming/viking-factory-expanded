require("prototypes.recipe.recipe-updates")
require("prototypes.productivity-limitations")
require("prototypes.technology.technology-updates")

if settings.startup["bobmods-tech-colorupdate"].value == true then
  data.raw.tool["science-pack-1"].icon = "__base__/graphics/icons/high-tech-science-pack.png"
  data.raw.tool["science-pack-2"].icon = "__base__/graphics/icons/science-pack-1.png"
  data.raw.tool["high-tech-science-pack"].icon = "__base__/graphics/icons/science-pack-2.png"
end
