--bobmods.lib.tech.replace_science_pack("logistics-3", "production-science-pack", "logistic-science-pack")
--bobmods.lib.tech.remove_science_pack("logistics-3", "science-pack-3")

bobmods.lib.tech.add_new_science_pack("rocket-silo", "logistic-science-pack", 1)


bobmods.lib.tech.remove_science_pack("logistics-3", "production-science-pack")


bobmods.lib.tech.replace_science_pack("character-logistic-slots-4", "production-science-pack", "logistic-science-pack")
bobmods.lib.tech.replace_science_pack("character-logistic-slots-5", "production-science-pack", "logistic-science-pack")
bobmods.lib.tech.replace_science_pack("character-logistic-slots-6", "production-science-pack", "logistic-science-pack")

bobmods.lib.tech.replace_science_pack("logistic-system", "production-science-pack", "logistic-science-pack")

bobmods.lib.tech.replace_science_pack("braking-force-3", "production-science-pack", "logistic-science-pack")
bobmods.lib.tech.replace_science_pack("braking-force-4", "production-science-pack", "logistic-science-pack")
bobmods.lib.tech.replace_science_pack("braking-force-5", "production-science-pack", "logistic-science-pack")
bobmods.lib.tech.replace_science_pack("braking-force-6", "production-science-pack", "logistic-science-pack")
bobmods.lib.tech.replace_science_pack("braking-force-7", "production-science-pack", "logistic-science-pack")

bobmods.lib.tech.replace_science_pack("inserter-capacity-bonus-4", "production-science-pack", "logistic-science-pack")
bobmods.lib.tech.replace_science_pack("inserter-capacity-bonus-5", "production-science-pack", "logistic-science-pack")
bobmods.lib.tech.replace_science_pack("inserter-capacity-bonus-6", "production-science-pack", "logistic-science-pack")
bobmods.lib.tech.replace_science_pack("inserter-capacity-bonus-7", "production-science-pack", "logistic-science-pack")

bobmods.lib.tech.replace_science_pack("worker-robots-speed-3", "production-science-pack", "logistic-science-pack")
bobmods.lib.tech.replace_science_pack("worker-robots-speed-4", "production-science-pack", "logistic-science-pack")
bobmods.lib.tech.replace_science_pack("worker-robots-speed-5", "production-science-pack", "logistic-science-pack")
bobmods.lib.tech.replace_science_pack("worker-robots-speed-6", "production-science-pack", "logistic-science-pack")

bobmods.lib.tech.replace_science_pack("worker-robots-storage-2", "production-science-pack", "logistic-science-pack")
bobmods.lib.tech.replace_science_pack("worker-robots-storage-3", "production-science-pack", "logistic-science-pack")


