if not bobmods then bobmods = {} end
if not bobmods.tech then bobmods.tech = {} end

require("prototypes.technology.technology")
require("prototypes.item.item")
require("prototypes.entity.entity")
require("prototypes.recipe.recipe")


require("prototypes.technology.technology-alien")
require("prototypes.item.item-alien")
require("prototypes.entity.entity-alien")
require("prototypes.recipe.recipe-alien")

